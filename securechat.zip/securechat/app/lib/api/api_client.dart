import 'dart:convert';
import 'dart:typed_data';
import 'package:dio/dio.dart';
import '../config.dart';
import '../storage/session_store.dart';

class SessionReplaced implements Exception {}

class ApiClient {
  ApiClient(this.session) {
    _dio.interceptors.add(InterceptorsWrapper(
      onRequest: (o, h) {
        final t = session.accessToken;
        if (t != null && o.extra['noauth'] != true) o.headers['Authorization'] = 'Bearer $t';
        h.next(o);
      },
      onError: (e, h) async {
        final status = e.response?.statusCode;
        if (status == 401 && e.requestOptions.extra['retried'] != true && session.refreshToken != null) {
          if (_msg(e) == 'SESSION_REPLACED') { onSessionReplaced?.call(); return h.reject(e); }
          try {
            await refresh();
            final o = e.requestOptions..extra['retried'] = true;
            o.headers['Authorization'] = 'Bearer ${session.accessToken}';
            return h.resolve(await _dio.fetch(o));
          } catch (_) {
            onSessionReplaced?.call();
          }
        }
        h.next(e);
      },
    ));
  }

  final SessionStore session;
  void Function()? onSessionReplaced;
  final _dio = Dio(BaseOptions(baseUrl: AppConfig.apiBase, connectTimeout: const Duration(seconds: 15), receiveTimeout: const Duration(seconds: 60)));

  String? _msg(DioException e) {
    final d = e.response?.data;
    return d is Map ? (d['message'] as String?) : null;
  }

  Future<Map<String, dynamic>> post(String path, Map<String, dynamic> body, {bool auth = true}) async =>
      (await _dio.post(path, data: body, options: Options(extra: {'noauth': !auth}))).data as Map<String, dynamic>;

  Future<void> refresh() async {
    final r = await post('/v1/auth/token/refresh', {'refreshToken': session.refreshToken}, auth: false);
    await session.saveTokens(r['accessToken'], r['refreshToken']);
  }

  Future<Map<String, dynamic>> get(String path, {Map<String, dynamic>? q}) async =>
      (await _dio.get(path, queryParameters: q)).data as Map<String, dynamic>;

  Future<void> putBytes(String path, Uint8List bytes, {Map<String, String>? headers}) =>
      _dio.put(path, data: Stream.fromIterable([bytes]),
          options: Options(contentType: 'application/octet-stream', headers: {...?headers, Headers.contentLengthHeader: bytes.length}));

  Future<Uint8List> getBytes(String path) async =>
      Uint8List.fromList((await _dio.get<List<int>>(path, options: Options(responseType: ResponseType.bytes))).data!);

  Future<void> delete(String path) => _dio.delete(path);

  static String b64(List<int> b) => base64.encode(b);
}
