import 'package:flutter/material.dart';
import 'app.dart';
import 'ui/screens.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await App.init();
  runApp(const SecureChatApp());
}

class SecureChatApp extends StatelessWidget {
  const SecureChatApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'SecureChat',
        theme: ThemeData(colorSchemeSeed: const Color(0xFF1F6FEB), useMaterial3: true),
        darkTheme: ThemeData(colorSchemeSeed: const Color(0xFF1F6FEB), brightness: Brightness.dark, useMaterial3: true),
        home: ValueListenableBuilder<bool>(
          valueListenable: App.loggedIn,
          builder: (_, ok, __) => ok ? const HomePage() : const WelcomePage(),
        ),
      );
}
