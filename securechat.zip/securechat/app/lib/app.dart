import 'package:flutter/foundation.dart';
import 'api/api_client.dart';
import 'backup/backup_service.dart';
import 'crypto/e2ee.dart';
import 'db/local_db.dart';
import 'services/account_service.dart';
import 'services/chat_service.dart';
import 'storage/session_store.dart';

/// সরল সার্ভিস কন্টেইনার (প্রোডাকশনে Riverpod/GetIt-এ সরানো যায়)
class App {
  static final session = SessionStore();
  static late final ApiClient api;
  static final E2eeEngine e2ee = SealedBoxE2ee();
  static late final AccountService account;
  static LocalDb? db;
  static BackupService? backup;
  static ChatService? chat;
  static final loggedIn = ValueNotifier<bool>(false);
  static final notice = ValueNotifier<String?>(null);

  static Future<void> init() async {
    await session.load();
    api = ApiClient(session)..onSessionReplaced = () => signOutLocally('অন্য ডিভাইসে লগইন হওয়ায় এই ডিভাইসের সেশন শেষ হয়েছে');
    account = AccountService(api, session, e2ee);
    if (session.loggedIn) await openSession();
  }

  /// লগইন/রিকভারির পর ডাটাবেস খোলা + সার্ভিস চালু
  static Future<void> openSession() async {
    db = await LocalDb.open(session.dbKey!);
    backup = BackupService(api, session, db!);
    chat = ChatService(api, session, db!, e2ee, backup!)..onKicked = () => signOutLocally('অন্য ডিভাইসে লগইন হওয়ায় এই ডিভাইসের সেশন শেষ হয়েছে');
    await chat!.start();
    loggedIn.value = true;
  }

  /// এই ডিভাইস থেকে সব লোকাল ডেটা ও কী মুছে ফেলা (হিস্টরি সার্ভারে এনক্রিপ্টেড ব্যাকআপে নিরাপদ)
  static Future<void> signOutLocally(String reason) async {
    chat?.stop();
    await db?.close();
    await LocalDb.wipe();
    await session.clearAll();
    await session.load(); // নতুন dbKey জেনারেট
    db = null; backup = null; chat = null;
    notice.value = reason;
    loggedIn.value = false;
  }
}
