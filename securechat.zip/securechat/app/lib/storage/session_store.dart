import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '../crypto/e2ee.dart';
import '../crypto/recovery_crypto.dart';

/// সব সিক্রেট থাকে Android Keystore / iOS Keychain-ব্যাকড স্টোরেজে।
class SessionStore {
  static const _s = FlutterSecureStorage(aOptions: AndroidOptions(encryptedSharedPreferences: true));

  String? userId, deviceId, accessToken, refreshToken;
  Uint8List? backupKey; // রিকভারি কোড থেকে ডিরাইভড; সার্ভারে যায় না
  Uint8List? dbKey; // SQLCipher কী (র‍্যান্ডম ২৫৬-বিট)
  IdentityKeys? identity;

  bool get loggedIn => accessToken != null && identity != null && backupKey != null;

  Future<void> load() async {
    userId = await _s.read(key: 'userId');
    deviceId = await _s.read(key: 'deviceId');
    accessToken = await _s.read(key: 'at');
    refreshToken = await _s.read(key: 'rt');
    final bk = await _s.read(key: 'backupKey');
    backupKey = bk == null ? null : base64.decode(bk);
    var dk = await _s.read(key: 'dbKey');
    if (dk == null) {
      dk = base64.encode(RecoveryCrypto.randomBytes(32));
      await _s.write(key: 'dbKey', value: dk);
    }
    dbKey = base64.decode(dk);
    final id = await _s.read(key: 'identity');
    identity = id == null ? null : IdentityKeys.fromJson(jsonDecode(id));
  }

  Future<void> saveTokens(String at, String rt) async {
    accessToken = at; refreshToken = rt;
    await _s.write(key: 'at', value: at);
    await _s.write(key: 'rt', value: rt);
  }

  Future<void> saveAccount({required String userId, required String deviceId, required IdentityKeys identity, required Uint8List backupKey}) async {
    this.userId = userId; this.deviceId = deviceId; this.identity = identity; this.backupKey = backupKey;
    await _s.write(key: 'userId', value: userId);
    await _s.write(key: 'deviceId', value: deviceId);
    await _s.write(key: 'identity', value: jsonEncode(identity.toJson()));
    await _s.write(key: 'backupKey', value: base64.encode(backupKey));
  }

  /// SESSION_REPLACED (অন্য ডিভাইসে লগইন) হলে: টোকেন/কী মুছে ফেলা। লোকাল DB-ও মুছতে হবে (কলার দায়িত্ব)।
  Future<void> clearAll() async {
    await _s.deleteAll();
    userId = deviceId = accessToken = refreshToken = null;
    backupKey = null; identity = null; dbKey = null;
  }
}
