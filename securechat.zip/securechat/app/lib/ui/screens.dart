import 'dart:async';
import 'package:audioplayers/audioplayers.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import '../app.dart';
import '../backup/backup_service.dart';
import '../crypto/recovery_crypto.dart';
import '../services/account_service.dart';
import '../services/chat_service.dart';

String errText(Object e) {
  if (e is DioException) {
    final d = e.response?.data;
    final m = d is Map ? (d['message'] ?? d['error']) : null;
    return 'ত্রুটি: ${m ?? e.message ?? e.type.name}';
  }
  return e.toString();
}

void toast(BuildContext c, String m) => ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m)));

// ───────────────────────── Welcome ─────────────────────────
class WelcomePage extends StatelessWidget {
  const WelcomePage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              const Icon(Icons.lock_outline, size: 72),
              const SizedBox(height: 16),
              Text('SecureChat', textAlign: TextAlign.center, style: Theme.of(context).textTheme.headlineMedium),
              const SizedBox(height: 8),
              const Text('এন্ড-টু-এন্ড এনক্রিপ্টেড মেসেজিং। সার্ভার আপনার মেসেজ পড়তে পারে না।', textAlign: TextAlign.center),
              ValueListenableBuilder<String?>(
                valueListenable: App.notice,
                builder: (_, n, __) => n == null ? const SizedBox(height: 32) : Padding(padding: const EdgeInsets.all(16), child: Text(n, textAlign: TextAlign.center, style: TextStyle(color: Theme.of(context).colorScheme.error))),
              ),
              FilledButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RegisterPage())), child: const Text('নতুন অ্যাকাউন্ট')),
              const SizedBox(height: 12),
              OutlinedButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RestorePage())), child: const Text('রিকভারি কোড দিয়ে অ্যাকাউন্ট ও হিস্টরি ফিরিয়ে আনুন')),
            ]),
          ),
        ),
      );
}

// ───────────────────────── Register ─────────────────────────
class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});
  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final phone = TextEditingController(), email = TextEditingController(), pOtp = TextEditingController(), eOtp = TextEditingController();
  String? challengeId;
  bool busy = false;

  Future<void> run(Future<void> Function() f) async {
    setState(() => busy = true);
    try { await f(); } catch (e) { if (mounted) toast(context, errText(e)); } finally { if (mounted) setState(() => busy = false); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('নতুন অ্যাকাউন্ট')),
        body: ListView(padding: const EdgeInsets.all(24), children: [
          if (challengeId == null) ...[
            TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'ফোন নম্বর (+8801XXXXXXXXX)')),
            const SizedBox(height: 12),
            TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'ইমেইল')),
            const SizedBox(height: 24),
            FilledButton(
              onPressed: busy ? null : () => run(() async {
                    final r = await App.account.registerStart(phone.text.trim(), email.text.trim());
                    setState(() => challengeId = r['challengeId']);
                    final dev = r['devOtp'];
                    if (dev != null && mounted) toast(context, 'DEV OTP → SMS ${dev['sms']}  Email ${dev['email']}');
                  }),
              child: const Text('OTP পাঠান'),
            ),
          ] else ...[
            const Text('ফোন ও ইমেইল দুটোতেই ৬ সংখ্যার কোড পাঠানো হয়েছে।'),
            const SizedBox(height: 12),
            TextField(controller: pOtp, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'ফোনের OTP')),
            const SizedBox(height: 12),
            TextField(controller: eOtp, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'ইমেইলের OTP')),
            const SizedBox(height: 24),
            FilledButton(
              onPressed: busy ? null : () => run(() async {
                    final tok = await App.account.registerVerify(challengeId!, pOtp.text.trim(), eOtp.text.trim());
                    final code = await App.account.registerComplete(tok); // কী জেনারেশন (Argon2id) সময় নিতে পারে
                    if (!mounted) return;
                    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => RecoveryCodePage(code: code)));
                  }),
              child: const Text('যাচাই করে অ্যাকাউন্ট তৈরি করুন'),
            ),
          ],
          if (busy) const Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator())),
        ]),
      );
}

// ───────────────────────── Recovery code ─────────────────────────
class RecoveryCodePage extends StatefulWidget {
  const RecoveryCodePage({super.key, required this.code});
  final String code;
  @override
  State<RecoveryCodePage> createState() => _RecoveryCodePageState();
}

class _RecoveryCodePageState extends State<RecoveryCodePage> {
  final confirm = TextEditingController();
  bool get matches => RecoveryCrypto.normalize(confirm.text) == RecoveryCrypto.normalize(widget.code);

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('আপনার রিকভারি কোড'), automaticallyImplyLeading: false),
        body: ListView(padding: const EdgeInsets.all(24), children: [
          const Text('ফোন হারালে বা বদলালে এই কোড দিয়েই অ্যাকাউন্ট ও সব চ্যাট, ভয়েস মেসেজ ও কল হিস্টরি ফিরে পাবেন। এটি কাগজে লিখে নিরাপদ জায়গায় রাখুন।'),
          const SizedBox(height: 16),
          Card(child: Padding(padding: const EdgeInsets.all(20), child: SelectableText(widget.code, textAlign: TextAlign.center, style: const TextStyle(fontSize: 26, letterSpacing: 2, fontFamily: 'monospace')))),
          const SizedBox(height: 12),
          Text('⚠️ আমরা এই কোড সংরক্ষণ করি না এবং কোনোভাবেই পুনরুদ্ধার করতে পারব না। হারালে পুরনো হিস্টরি চিরতরে অপাঠ্য হবে।', style: TextStyle(color: Theme.of(context).colorScheme.error)),
          const SizedBox(height: 16),
          TextField(controller: confirm, onChanged: (_) => setState(() {}), textCapitalization: TextCapitalization.characters, decoration: const InputDecoration(labelText: 'নিশ্চিত করতে কোডটি আবার লিখুন')),
          const SizedBox(height: 16),
          FilledButton(
            onPressed: matches ? () async {
              await App.openSession();
              App.backup!.backupNow().catchError((_) {});
              if (context.mounted) Navigator.of(context).popUntil((r) => r.isFirst);
            } : null,
            child: const Text('লিখে রেখেছি, চালিয়ে যান'),
          ),
        ]),
      );
}

// ───────────────────────── Restore ─────────────────────────
class RestorePage extends StatefulWidget {
  const RestorePage({super.key});
  @override
  State<RestorePage> createState() => _RestorePageState();
}

class _RestorePageState extends State<RestorePage> {
  final phone = TextEditingController(), pOtp = TextEditingController(), eOtp = TextEditingController(), code = TextEditingController();
  RecoveryChallenge? ch;
  bool busy = false;
  String status = '';

  Future<void> run(Future<void> Function() f) async {
    setState(() => busy = true);
    try { await f(); } catch (e) { if (mounted) toast(context, e is BackupDecryptError ? e.toString() : errText(e)); } finally { if (mounted) setState(() { busy = false; status = ''; }); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('অ্যাকাউন্ট ও হিস্টরি রিস্টোর')),
        body: ListView(padding: const EdgeInsets.all(24), children: [
          if (ch == null) ...[
            const Text('পুরনো ডিভাইসে লগইন থাকলে তা বন্ধ হয়ে যাবে।'),
            const SizedBox(height: 12),
            TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'ফোন নম্বর (+8801XXXXXXXXX)')),
            const SizedBox(height: 24),
            FilledButton(onPressed: busy ? null : () => run(() async {
              final c = await App.account.recoveryStart(phone.text.trim());
              setState(() => ch = c);
              final dev = c.devOtp;
              if (dev != null && mounted) toast(context, 'DEV OTP → SMS ${dev['sms']}  Email ${dev['email']}');
            }), child: const Text('OTP পাঠান')),
          ] else ...[
            TextField(controller: pOtp, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'ফোনের OTP')),
            const SizedBox(height: 12),
            TextField(controller: eOtp, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'ইমেইলের OTP')),
            const SizedBox(height: 12),
            TextField(controller: code, textCapitalization: TextCapitalization.characters, decoration: const InputDecoration(labelText: 'রিকভারি কোড (XXXX-XXXX-XXXX-XXXX)')),
            const SizedBox(height: 24),
            FilledButton(onPressed: busy ? null : () => run(() async {
              setState(() => status = 'কোড যাচাই হচ্ছে (কয়েক সেকেন্ড লাগতে পারে)…');
              await App.account.recoveryVerify(ch!, pOtp.text.trim(), eOtp.text.trim(), code.text);
              await App.openSession();
              final r = await App.backup!.restore(onProgress: (d, t) { if (mounted) setState(() => status = 'হিস্টরি ফেরত আনা হচ্ছে… $d/$t'); });
              if (!mounted) return;
              await showDialog(context: context, builder: (_) => AlertDialog(
                title: const Text('রিস্টোর সম্পন্ন'),
                content: Text('${r.messages} মেসেজ (${r.voiceMessages} ভয়েস), ${r.calls} কল হিস্টরি ফেরত এসেছে।'),
                actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('ঠিক আছে'))],
              ));
              if (mounted) Navigator.of(context).popUntil((r) => r.isFirst);
            }), child: const Text('রিস্টোর করুন')),
          ],
          if (busy) Padding(padding: const EdgeInsets.all(24), child: Column(children: [const CircularProgressIndicator(), const SizedBox(height: 12), Text(status)])),
        ]),
      );
}

// ───────────────────────── Home ─────────────────────────
class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late final StreamSubscription _sub = App.chat!.changes.listen((_) => setState(() {}));

  @override
  void dispose() { _sub.cancel(); super.dispose(); }

  Future<void> newChat() async {
    final c = TextEditingController();
    final phone = await showDialog<String>(context: context, builder: (_) => AlertDialog(
      title: const Text('নতুন চ্যাট'),
      content: TextField(controller: c, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'ফোন নম্বর (+880…)')),
      actions: [TextButton(onPressed: () => Navigator.pop(context, c.text.trim()), child: const Text('শুরু করুন'))],
    ));
    if (phone == null || phone.isEmpty) return;
    final id = await App.chat!.lookupPhone(phone);
    if (!mounted) return;
    if (id == null) { toast(context, 'এই নম্বরে কোনো অ্যাকাউন্ট নেই'); return; }
    Navigator.push(context, MaterialPageRoute(builder: (_) => ChatPage(peerId: id, title: phone)));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('চ্যাট'), actions: [
          PopupMenuButton<String>(
            onSelected: (v) async {
              if (v == 'backup') {
                try { await App.backup!.backupNow(); if (mounted) toast(context, 'ব্যাকআপ সম্পন্ন'); } catch (e) { if (mounted) toast(context, errText(e)); }
              } else if (v == 'rotate') {
                try {
                  final code = await App.account.rotateRecoveryCode(App.db!, App.backup!);
                  if (!mounted) return;
                  Navigator.push(context, MaterialPageRoute(builder: (_) => RecoveryCodePage(code: code)));
                } catch (e) { if (mounted) toast(context, errText(e)); }
              }
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'backup', child: Text('এখনই ব্যাকআপ')),
              PopupMenuItem(value: 'rotate', child: Text('নতুন রিকভারি কোড')),
            ],
          ),
        ]),
        floatingActionButton: FloatingActionButton(onPressed: newChat, child: const Icon(Icons.edit)),
        body: FutureBuilder<List<Map<String, Object?>>>(
          future: App.db!.conversations(),
          builder: (_, s) {
            final list = s.data ?? [];
            if (list.isEmpty) return const Center(child: Text('এখনো কোনো চ্যাট নেই'));
            return ListView.separated(
              itemCount: list.length, separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (_, i) {
                final c = list[i];
                final title = (c['name'] as String?) ?? (c['peer_id'] as String).substring(0, 8);
                return ListTile(
                  leading: const CircleAvatar(child: Icon(Icons.person)),
                  title: Text(title),
                  subtitle: Text(c['kind'] == 'voice' ? '🎤 ভয়েস মেসেজ' : (c['body'] as String? ?? ''), maxLines: 1, overflow: TextOverflow.ellipsis),
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChatPage(peerId: c['peer_id'] as String, title: title))).then((_) => setState(() {})),
                );
              },
            );
          },
        ),
      );
}

// ───────────────────────── Chat ─────────────────────────
class ChatPage extends StatefulWidget {
  const ChatPage({super.key, required this.peerId, required this.title});
  final String peerId, title;
  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final input = TextEditingController();
  final recorder = VoiceRecorder();
  final player = AudioPlayer();
  bool recording = false;
  late final StreamSubscription _sub = App.chat!.changes.where((p) => p == widget.peerId).listen((_) => setState(() {}));

  @override
  void dispose() { _sub.cancel(); player.dispose(); super.dispose(); }

  Future<void> send() async {
    final t = input.text.trim();
    if (t.isEmpty) return;
    input.clear();
    try { await App.chat!.sendText(widget.peerId, t); } catch (e) { if (mounted) toast(context, errText(e)); }
  }

  Future<void> toggleRecord() async {
    if (!recording) {
      if (await recorder.start()) setState(() => recording = true);
      return;
    }
    setState(() => recording = false);
    final r = await recorder.stop();
    if (r == null) return;
    try { await App.chat!.sendVoice(widget.peerId, r.$1, r.$2); } catch (e) { if (mounted) toast(context, errText(e)); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(widget.title)),
        body: Column(children: [
          Expanded(
            child: FutureBuilder<List<Map<String, Object?>>>(
              future: App.db!.thread(widget.peerId),
              builder: (_, s) {
                final msgs = s.data ?? [];
                return ListView.builder(
                  padding: const EdgeInsets.all(12), itemCount: msgs.length,
                  itemBuilder: (_, i) {
                    final m = msgs[i];
                    final mine = m['outgoing'] == 1;
                    final voice = m['kind'] == 'voice';
                    return Align(
                      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                      child: Container(
                        margin: const EdgeInsets.symmetric(vertical: 3), padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(color: mine ? Theme.of(context).colorScheme.primaryContainer : Theme.of(context).colorScheme.surfaceContainerHighest, borderRadius: BorderRadius.circular(12)),
                        child: voice
                            ? Row(mainAxisSize: MainAxisSize.min, children: [
                                IconButton(icon: const Icon(Icons.play_arrow), onPressed: () async {
                                  try { final f = await App.chat!.voiceFile(m); await player.play(DeviceFileSource(f.path)); } catch (e) { if (mounted) toast(context, 'ভয়েস মেসেজ চালানো যায়নি: ${errText(e)}'); }
                                }),
                                Text('${((m['duration_ms'] as int? ?? 0) / 1000).round()}s'),
                              ])
                            : Text(m['body'] as String? ?? ''),
                      ),
                    );
                  },
                );
              },
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Row(children: [
                IconButton(icon: Icon(recording ? Icons.stop_circle : Icons.mic, color: recording ? Colors.red : null), onPressed: toggleRecord),
                Expanded(child: TextField(controller: input, decoration: const InputDecoration(hintText: 'মেসেজ লিখুন…', border: OutlineInputBorder()), onSubmitted: (_) => send())),
                IconButton(icon: const Icon(Icons.send), onPressed: send),
              ]),
            ),
          ),
        ]),
      );
}
