import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:cryptography/cryptography.dart';
import 'package:sqflite_sqlcipher/sqflite.dart' show ConflictAlgorithm;
import '../api/api_client.dart';
import '../db/local_db.dart';
import '../storage/session_store.dart';

/// এনক্রিপ্টেড হিস্টরি ব্যাকআপ/রিস্টোর।
///
/// কী ব্যাকআপ হয়: চ্যাট মেসেজ, ভয়েস মেসেজ (blobId + মিডিয়া কী; অডিও blob নিজে সার্ভারে এনক্রিপ্টেড থাকে),
/// ফাইল রেফারেন্স, কল হিস্টরি, কন্টাক্ট।
/// কীভাবে: JSON → gzip → AES-256-GCM (backupKey)। backupKey রিকভারি কোড থেকে ডিরাইভড, সার্ভারে যায় না।
/// ফরম্যাট: snapshot (সব) + delta (শেষ ব্যাকআপের পর বদলানো সারি)। প্রতি [_compactEvery] delta-তে নতুন snapshot + compaction।
class BackupService {
  BackupService(this.api, this.session, this.db);
  final ApiClient api;
  final SessionStore session;
  final LocalDb db;

  static const _compactEvery = 40;
  final _aes = AesGcm.with256bits();
  Timer? _debounce;
  bool _running = false;

  /// মেসেজ/কল বদলালে ডাকুন; ৩০ সেকেন্ড জমিয়ে একবার ব্যাকআপ হবে
  void schedule() {
    _debounce?.cancel();
    _debounce = Timer(const Duration(seconds: 30), () => backupNow().catchError((_) {}));
  }

  List<int> _aad(int seq, String kind) => utf8.encode('sc-backup-v1|${session.userId}|$seq|$kind');

  Future<Uint8List> _seal(Map<String, dynamic> payload, int seq, String kind) async {
    final plain = gzip.encode(utf8.encode(jsonEncode(payload)));
    final box = await _aes.encrypt(plain, secretKey: SecretKey(session.backupKey!), aad: _aad(seq, kind));
    return Uint8List.fromList(box.concatenation());
  }

  Future<Map<String, dynamic>> _open(Uint8List bytes, int seq, String kind) async {
    final box = SecretBox.fromConcatenation(bytes, nonceLength: 12, macLength: 16);
    final plain = await _aes.decrypt(box, secretKey: SecretKey(session.backupKey!), aad: _aad(seq, kind));
    return jsonDecode(utf8.decode(gzip.decode(plain))) as Map<String, dynamic>;
  }

  Future<Map<String, dynamic>> _export({required int since}) async {
    final tables = <String, List<Map<String, Object?>>>{};
    for (final t in LocalDb.backupTables) {
      tables[t] = await db.db.query(t, where: 'updated_at > ?', whereArgs: [since]);
    }
    return {'v': 1, 'tables': tables};
  }

  /// এখনই ব্যাকআপ। কিছু বদলায়নি হলে কিছুই আপলোড হয় না।
  Future<void> backupNow() async {
    if (_running) return;
    _running = true;
    try {
      final last = int.parse(await db.kv('backup_last_ts') ?? '0');
      var seq = int.parse(await db.kv('backup_seq') ?? '0');
      final deltasSinceSnap = int.parse(await db.kv('backup_deltas') ?? '0');
      final startedAt = LocalDb.now();
      final needSnapshot = seq == 0 || deltasSinceSnap >= _compactEvery;
      final data = await _export(since: needSnapshot ? 0 : last);
      final empty = (data['tables'] as Map).values.every((l) => (l as List).isEmpty);
      if (empty && !needSnapshot) return;

      seq += 1;
      final kind = needSnapshot ? 'snapshot' : 'delta';
      final blob = await _seal(data, seq, kind);
      await api.putBytes('/v1/backup/segments/$seq', blob, headers: {'x-segment-kind': kind});
      if (needSnapshot && seq > 1) await api.post('/v1/backup/compact', {'keepFromSeq': seq});
      await db.setKv('backup_seq', '$seq');
      await db.setKv('backup_last_ts', '$startedAt');
      await db.setKv('backup_deltas', needSnapshot ? '0' : '${deltasSinceSnap + 1}');
    } finally {
      _running = false;
    }
  }

  /// রিকভারির পর নতুন ডিভাইসে হিস্টরি ফেরত আনা।
  /// ভুল backupKey হলে AES-GCM অথেনটিকেশন ব্যর্থ হয় → [BackupDecryptError]।
  Future<RestoreResult> restore({void Function(int done, int total)? onProgress}) async {
    final manifest = (await api.get('/v1/backup/manifest'))['segments'] as List;
    if (manifest.isEmpty) return RestoreResult(0, 0, 0);

    final segs = manifest.cast<Map<String, dynamic>>();
    // সর্বশেষ snapshot থেকে শুরু করে ক্রমানুসারে প্রয়োগ
    final lastSnap = segs.lastIndexWhere((s) => s['kind'] == 'snapshot');
    final chain = segs.sublist(lastSnap < 0 ? 0 : lastSnap);

    var msgs = 0, calls = 0, voice = 0;
    for (var i = 0; i < chain.length; i++) {
      final s = chain[i];
      final seq = s['seq'] as int;
      final bytes = await api.getBytes('/v1/backup/segments/$seq');
      Map<String, dynamic> payload;
      try {
        payload = await _open(bytes, seq, s['kind'] as String);
      } on SecretBoxAuthenticationError {
        throw BackupDecryptError();
      }
      final tables = payload['tables'] as Map<String, dynamic>;
      await db.db.transaction((txn) async {
        for (final t in LocalDb.backupTables) {
          for (final row in (tables[t] as List? ?? const [])) {
            final r = Map<String, Object?>.from(row as Map);
            final pk = t == 'contacts' ? 'user_id' : 'id';
            final existing = await txn.query(t, columns: ['updated_at'], where: '$pk=?', whereArgs: [r[pk]]);
            // নতুনটাই জেতে (last-writer-wins by updated_at)
            if (existing.isNotEmpty && (existing.first['updated_at'] as int) > (r['updated_at'] as int)) continue;
            await txn.insert(t, r, conflictAlgorithm: ConflictAlgorithm.replace);
            if (t == 'messages') { msgs++; if (r['kind'] == 'voice') voice++; }
            if (t == 'calls') calls++;
          }
        }
      });
      onProgress?.call(i + 1, chain.length);
    }
    // পরবর্তী ব্যাকআপ যেন একই seq-এর পরে চলে
    await db.setKv('backup_seq', '${chain.last['seq']}');
    await db.setKv('backup_last_ts', '${LocalDb.now()}');
    await db.setKv('backup_deltas', '${chain.length - 1}');
    return RestoreResult(msgs, voice, calls);
  }
}

class RestoreResult {
  RestoreResult(this.messages, this.voiceMessages, this.calls);
  final int messages, voiceMessages, calls;
}

class BackupDecryptError implements Exception {
  @override
  String toString() => 'ব্যাকআপ ডিক্রিপ্ট করা যায়নি: রিকভারি কোড ভুল বা ব্যাকআপ নষ্ট';
}
