import 'dart:convert';
import 'dart:typed_data';
import 'package:cryptography/cryptography.dart';

/// ⚠️ MVP প্লেসহোল্ডার E2EE (X25519 + HKDF + AES-256-GCM, প্রতি মেসেজে ephemeral কী)।
/// এতে Double Ratchet নেই, তাই forward secrecy / post-compromise security সীমিত।
/// প্রোডাকশনের আগে libsignal (X3DH + Double Ratchet) দিয়ে এই ইন্টারফেসটি বদলান;
/// বাকি অ্যাপ শুধু [E2eeEngine]-এর ওপর নির্ভর করে, তাই বদলানো সহজ।
abstract class E2eeEngine {
  Future<IdentityKeys> generateIdentity();
  Future<Uint8List> encrypt(PeerBundle peer, Uint8List plaintext);
  Future<Uint8List> decrypt(IdentityKeys mine, Uint8List envelope);
  Future<bool> verifyBundle(PeerBundle peer);
}

class IdentityKeys {
  IdentityKeys({required this.signingSeed, required this.signingPub, required this.prekeySeed, required this.prekeyPub, required this.prekeySig, required this.registrationId});
  final Uint8List signingSeed; // Ed25519 (ডিভাইস অথ + আইডেন্টিটি)
  final Uint8List signingPub;
  final Uint8List prekeySeed; // X25519 signed-prekey private
  final Uint8List prekeyPub;
  final Uint8List prekeySig;
  final int registrationId;

  Map<String, dynamic> toJson() => {
        'ss': base64.encode(signingSeed), 'sp': base64.encode(signingPub),
        'ps': base64.encode(prekeySeed), 'pp': base64.encode(prekeyPub),
        'pg': base64.encode(prekeySig), 'rid': registrationId,
      };
  static IdentityKeys fromJson(Map<String, dynamic> j) => IdentityKeys(
        signingSeed: base64.decode(j['ss']), signingPub: base64.decode(j['sp']),
        prekeySeed: base64.decode(j['ps']), prekeyPub: base64.decode(j['pp']),
        prekeySig: base64.decode(j['pg']), registrationId: j['rid'],
      );
}

class PeerBundle {
  PeerBundle(this.userId, this.identityKey, this.prekeyPub, this.prekeySig);
  final String userId;
  final Uint8List identityKey;
  final Uint8List prekeyPub;
  final Uint8List prekeySig;
  factory PeerBundle.fromApi(Map<String, dynamic> j) => PeerBundle(
        j['userId'], base64.decode(j['identityKey']),
        base64.decode(j['signedPrekey']['publicKey']), base64.decode(j['signedPrekey']['signature']),
      );
}

class SealedBoxE2ee implements E2eeEngine {
  final _x = X25519();
  final _ed = Ed25519();
  final _aes = AesGcm.with256bits();
  final _hkdf = Hkdf(hmac: Hmac.sha256(), outputLength: 32);

  @override
  Future<IdentityKeys> generateIdentity() async {
    final sign = await _ed.newKeyPair();
    final signSeed = await sign.extractPrivateKeyBytes();
    final signPub = (await sign.extractPublicKey()).bytes;
    final pre = await _x.newKeyPair();
    final preSeed = await pre.extractPrivateKeyBytes();
    final prePub = (await pre.extractPublicKey()).bytes;
    final sig = await _ed.sign(prePub, keyPair: sign);
    final rid = (DateTime.now().microsecondsSinceEpoch % 16380) + 1;
    return IdentityKeys(
      signingSeed: Uint8List.fromList(signSeed), signingPub: Uint8List.fromList(signPub),
      prekeySeed: Uint8List.fromList(preSeed), prekeyPub: Uint8List.fromList(prePub),
      prekeySig: Uint8List.fromList(sig.bytes), registrationId: rid,
    );
  }

  @override
  Future<bool> verifyBundle(PeerBundle p) => _ed.verify(
        p.prekeyPub,
        signature: Signature(p.prekeySig, publicKey: SimplePublicKey(p.identityKey, type: KeyPairType.ed25519)),
      );

  Future<SecretKey> _key(SecretKey shared, List<int> eph, List<int> recip) =>
      _hkdf.deriveKey(secretKey: shared, nonce: const [], info: [...utf8.encode('sc-msg-v1'), ...eph, ...recip]);

  @override
  Future<Uint8List> encrypt(PeerBundle peer, Uint8List plaintext) async {
    if (!await verifyBundle(peer)) throw StateError('bundle signature invalid');
    final eph = await _x.newKeyPair();
    final ephPub = (await eph.extractPublicKey()).bytes;
    final shared = await _x.sharedSecretKey(keyPair: eph, remotePublicKey: SimplePublicKey(peer.prekeyPub, type: KeyPairType.x25519));
    final box = await _aes.encrypt(plaintext, secretKey: await _key(shared, ephPub, peer.prekeyPub), aad: ephPub);
    return Uint8List.fromList([...ephPub, ...box.concatenation()]);
  }

  @override
  Future<Uint8List> decrypt(IdentityKeys mine, Uint8List env) async {
    final ephPub = env.sublist(0, 32);
    final pair = SimpleKeyPairData(mine.prekeySeed,
        publicKey: SimplePublicKey(mine.prekeyPub, type: KeyPairType.x25519), type: KeyPairType.x25519);
    final shared = await _x.sharedSecretKey(keyPair: pair, remotePublicKey: SimplePublicKey(ephPub, type: KeyPairType.x25519));
    final box = SecretBox.fromConcatenation(env.sublist(32), nonceLength: 12, macLength: 16);
    return Uint8List.fromList(await _aes.decrypt(box, secretKey: await _key(shared, ephPub, mine.prekeyPub), aad: ephPub));
  }
}
