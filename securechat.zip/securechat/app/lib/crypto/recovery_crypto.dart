import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';
import 'package:cryptography/cryptography.dart';

/// রিকভারি কোড থেকে তিনটি জিনিস ডিরাইভ হয়:
///   root        = Argon2id(code, clientSalt)           (কখনো কোথাও যায় না)
///   verifier    = HKDF(root, "sc-auth-verifier")       (সার্ভারে যায়; সার্ভার আবার Argon2id+pepper দিয়ে হ্যাশ করে)
///   backupKey   = HKDF(root, "sc-backup-key")          (কখনো সার্ভারে যায় না; হিস্টরি ব্যাকআপ ডিক্রিপ্ট করে)
/// কোডটি নিজে নেটওয়ার্কে যায় না। কোড ছাড়া backupKey পুনরুদ্ধার গাণিতিকভাবে অসম্ভব।
class RecoveryMaterial {
  RecoveryMaterial(this.verifier, this.backupKey);
  final Uint8List verifier;
  final Uint8List backupKey;
}

class RecoveryCrypto {
  static const defaultKdf = {'alg': 'argon2id', 'm': 65536, 't': 3, 'p': 4};
  static const _alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

  static Uint8List randomBytes(int n) {
    final r = Random.secure();
    return Uint8List.fromList(List.generate(n, (_) => r.nextInt(256)));
  }

  /// ১০ র‍্যান্ডম বাইট (৮০ বিট) → Base32 → ঠিক ১৬ অক্ষর
  static String generateCode() {
    final bytes = randomBytes(10);
    var bits = 0, value = 0;
    final out = StringBuffer();
    for (final b in bytes) {
      value = (value << 8) | b;
      bits += 8;
      while (bits >= 5) {
        out.write(_alphabet[(value >> (bits - 5)) & 31]);
        bits -= 5;
      }
    }
    return out.toString();
  }

  static String format(String code) =>
      List.generate(4, (i) => code.substring(i * 4, i * 4 + 4)).join('-');

  /// ইউজারের টাইপ করা ইনপুট: ড্যাশ/স্পেস বাদ, বড় হাতের অক্ষর
  static String normalize(String input) =>
      input.toUpperCase().replaceAll(RegExp(r'[^A-Z2-7]'), '');

  static bool isValid(String input) => normalize(input).length == 16;

  static Future<RecoveryMaterial> derive(String code, Uint8List clientSalt, Map<String, dynamic> kdf) async {
    final argon = Argon2id(
      memory: kdf['m'] as int,
      iterations: kdf['t'] as int,
      parallelism: kdf['p'] as int,
      hashLength: 64,
    );
    final root = await argon.deriveKeyFromPassword(password: normalize(code), nonce: clientSalt);
    final rootBytes = await root.extractBytes();
    final hkdf = Hkdf(hmac: Hmac.sha256(), outputLength: 32);
    Future<Uint8List> sub(String info) async {
      final k = await hkdf.deriveKey(secretKey: SecretKey(rootBytes), nonce: const [], info: utf8.encode(info));
      return Uint8List.fromList(await k.extractBytes());
    }
    return RecoveryMaterial(await sub('sc-auth-verifier'), await sub('sc-backup-key'));
  }
}
