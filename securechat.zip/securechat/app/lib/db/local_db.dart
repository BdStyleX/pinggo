import 'dart:io';
import 'dart:typed_data';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite_sqlcipher/sqflite.dart';

/// SQLCipher (AES-256) এনক্রিপ্টেড লোকাল ডাটাবেস।
/// প্রতিটি সারিতে updated_at (ms) থাকে: ব্যাকআপ delta ও রিস্টোরের merge এর ভিত্তি।
/// মুছে ফেলা = deleted=1 টম্বস্টোন (যাতে রিস্টোরে মুছে ফেলা মেসেজ ফিরে না আসে)।
class LocalDb {
  LocalDb._(this.db);
  final Database db;

  static const backupTables = ['contacts', 'messages', 'calls'];

  static Future<LocalDb> open(Uint8List key) async {
    final dir = await getApplicationDocumentsDirectory();
    final hex = key.map((b) => b.toRadixString(16).padLeft(2, '0')).join();
    final db = await openDatabase(
      p.join(dir.path, 'chat.db'),
      password: hex,
      version: 1,
      onCreate: (d, _) async {
        await d.execute('''CREATE TABLE contacts(
          user_id TEXT PRIMARY KEY, phone TEXT, name TEXT, updated_at INTEGER NOT NULL, deleted INTEGER NOT NULL DEFAULT 0)''');
        await d.execute('''CREATE TABLE messages(
          id TEXT PRIMARY KEY, peer_id TEXT NOT NULL, outgoing INTEGER NOT NULL,
          kind TEXT NOT NULL,            -- text | voice | file
          body TEXT, media_id TEXT, media_key TEXT, media_mime TEXT, duration_ms INTEGER,
          status TEXT NOT NULL,          -- sending | sent | delivered | received
          ts INTEGER NOT NULL, updated_at INTEGER NOT NULL, deleted INTEGER NOT NULL DEFAULT 0)''');
        await d.execute('CREATE INDEX idx_msg_peer ON messages(peer_id, ts)');
        await d.execute('''CREATE TABLE calls(
          id TEXT PRIMARY KEY, peer_id TEXT NOT NULL, outgoing INTEGER NOT NULL, type TEXT NOT NULL,
          status TEXT NOT NULL, started_at INTEGER NOT NULL, duration_s INTEGER NOT NULL DEFAULT 0,
          updated_at INTEGER NOT NULL, deleted INTEGER NOT NULL DEFAULT 0)''');
        await d.execute('CREATE TABLE kv(k TEXT PRIMARY KEY, v TEXT)');
      },
    );
    return LocalDb._(db);
  }

  static int now() => DateTime.now().millisecondsSinceEpoch;

  Future<void> upsertMessage(Map<String, Object?> m) async {
    await db.insert('messages', {...m, 'updated_at': now()}, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<void> setStatus(String id, String status) =>
      db.update('messages', {'status': status, 'updated_at': now()}, where: 'id=?', whereArgs: [id]);

  Future<void> upsertContact(String userId, {String? phone, String? name}) async {
    await db.insert('contacts', {'user_id': userId, 'phone': phone, 'name': name ?? phone, 'updated_at': now(), 'deleted': 0},
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<void> addCall(Map<String, Object?> c) =>
      db.insert('calls', {...c, 'updated_at': now()}, conflictAlgorithm: ConflictAlgorithm.replace);

  Future<List<Map<String, Object?>>> thread(String peerId) =>
      db.query('messages', where: 'peer_id=? AND deleted=0', whereArgs: [peerId], orderBy: 'ts ASC');

  Future<List<Map<String, Object?>>> conversations() => db.rawQuery('''
      SELECT m.peer_id, c.name, m.body, m.kind, m.ts FROM messages m
      LEFT JOIN contacts c ON c.user_id = m.peer_id
      WHERE m.deleted=0 AND m.ts = (SELECT max(ts) FROM messages WHERE peer_id=m.peer_id AND deleted=0)
      ORDER BY m.ts DESC''');

  Future<String?> kv(String k) async {
    final r = await db.query('kv', where: 'k=?', whereArgs: [k]);
    return r.isEmpty ? null : r.first['v'] as String?;
  }
  Future<void> setKv(String k, String v) => db.insert('kv', {'k': k, 'v': v}, conflictAlgorithm: ConflictAlgorithm.replace);

  Future<void> close() => db.close();

  static Future<void> wipe() async {
    final dir = await getApplicationDocumentsDirectory();
    final f = File(p.join(dir.path, 'chat.db'));
    if (await f.exists()) await f.delete();
  }
}
