class AppConfig {
  /// Android emulator থেকে লোকাল ব্যাকএন্ড: 10.0.2.2। প্রোডাকশনে https://api.example.com
  static const apiBase = String.fromEnvironment('API_BASE', defaultValue: 'http://10.0.2.2:3000');
  static String get wsUrl => '${apiBase.replaceFirst('http', 'ws')}/v1/ws';
}
