import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:cryptography/cryptography.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:uuid/uuid.dart';
import 'package:web_socket_channel/io.dart';
import '../api/api_client.dart';
import '../backup/backup_service.dart';
import '../config.dart';
import '../crypto/e2ee.dart';
import '../db/local_db.dart';
import '../storage/session_store.dart';

/// WebSocket চ্যাট ক্লায়েন্ট: এনক্রিপ্ট → সার্ভারে (blind relay) → ডিক্রিপ্ট → SQLCipher।
/// ভয়েস মেসেজ: র‍্যান্ডম AES-256 কী দিয়ে অডিও এনক্রিপ্ট → /v1/media/:id আপলোড → blobId+কী E2EE মেসেজে।
/// একই blobId+কী ব্যাকআপেও থাকে, তাই রিস্টোরের পর ভয়েস মেসেজ আবার চালানো যায়।
class ChatService {
  ChatService(this.api, this.session, this.db, this.e2ee, this.backup);
  final ApiClient api;
  final SessionStore session;
  final LocalDb db;
  final E2eeEngine e2ee;
  final BackupService backup;

  final _uuid = const Uuid();
  final _changes = StreamController<String>.broadcast(); // peerId
  Stream<String> get changes => _changes.stream;
  void Function()? onKicked;

  IOWebSocketChannel? _ch;
  bool _stopped = false;
  int _retry = 0;
  final _bundles = <String, PeerBundle>{};
  final _aes = AesGcm.with256bits();

  Future<void> start() async {
    _stopped = false;
    _connect();
  }

  void stop() {
    _stopped = true;
    _ch?.sink.close();
  }

  void _connect() {
    if (_stopped) return;
    final ch = IOWebSocketChannel.connect(Uri.parse(AppConfig.wsUrl),
        headers: {'Authorization': 'Bearer ${session.accessToken}'}, pingInterval: const Duration(seconds: 25));
    _ch = ch;
    ch.stream.listen(
      (data) => _onFrame(jsonDecode(data as String)).catchError((_) {}),
      onDone: () async {
        final code = ch.closeCode;
        if (code == 4001) { onKicked?.call(); return; } // অন্য ডিভাইসে লগইন হয়েছে
        if (code == 4401) { try { await api.refresh(); } catch (_) {} }
        if (_stopped) return;
        _retry = (_retry + 1).clamp(1, 6);
        Future.delayed(Duration(seconds: 1 << _retry), _connect);
      },
      onError: (_) {},
    );
    _retry = 0;
  }

  Future<void> _onFrame(Map<String, dynamic> f) async {
    switch (f['t']) {
      case 'msg':
        final plain = await e2ee.decrypt(session.identity!, base64.decode(f['ct']));
        final m = jsonDecode(utf8.decode(plain)) as Map<String, dynamic>;
        await db.upsertContact(f['from']); // নতুন সেন্ডার হলে কন্টাক্ট তৈরি (নাম পরে সেট করা যায়)
        await db.upsertMessage({
          'id': f['id'], 'peer_id': f['from'], 'outgoing': 0, 'kind': m['k'], 'body': m['body'],
          'media_id': m['mid'], 'media_key': m['mkey'], 'media_mime': m['mime'], 'duration_ms': m['dur'],
          'status': 'received', 'ts': (f['ts'] as int) * 1000,
        });
        _send({'t': 'ack', 'id': f['id']});
        _changes.add(f['from']);
        backup.schedule();
        break;
      case 'sent':
        await db.setStatus(f['id'], 'sent');
        break;
      case 'delivered':
        await db.setStatus(f['id'], 'delivered');
        break;
      case 'kick':
        onKicked?.call();
        break;
    }
  }

  void _send(Map<String, dynamic> f) => _ch?.sink.add(jsonEncode(f));

  Future<PeerBundle> _bundle(String userId) async {
    // MVP: প্রতিবার ফ্রেশ বান্ডেল (পেয়ার রিকভারি করলে নতুন কী সাথে সাথে ধরা পড়ে)
    final b = PeerBundle.fromApi(await api.get('/v1/keys/bundle/$userId'));
    _bundles[userId] = b;
    return b;
  }

  Future<void> _sendPayload(String peerId, Map<String, dynamic> payload, Map<String, Object?> row) async {
    final id = _uuid.v4();
    final ct = await e2ee.encrypt(await _bundle(peerId), Uint8List.fromList(utf8.encode(jsonEncode(payload))));
    await db.upsertMessage({...row, 'id': id, 'peer_id': peerId, 'outgoing': 1, 'status': 'sending', 'ts': LocalDb.now()});
    _send({'t': 'send', 'id': id, 'to': peerId, 'ct': base64.encode(ct), 'type': 1});
    _changes.add(peerId);
    backup.schedule();
  }

  Future<void> sendText(String peerId, String text) =>
      _sendPayload(peerId, {'k': 'text', 'body': text}, {'kind': 'text', 'body': text});

  /// অডিও ফাইল এনক্রিপ্ট করে আপলোড, তারপর E2EE মেসেজে blobId+কী পাঠানো
  Future<void> sendVoice(String peerId, File audio, int durationMs) async {
    final key = await _aes.newSecretKey();
    final keyBytes = await key.extractBytes();
    final box = await _aes.encrypt(await audio.readAsBytes(), secretKey: key);
    final blobId = _uuid.v4();
    await api.putBytes('/v1/media/$blobId', Uint8List.fromList(box.concatenation()));
    final mkey = base64.encode(keyBytes);
    await _sendPayload(peerId, {'k': 'voice', 'mid': blobId, 'mkey': mkey, 'mime': 'audio/m4a', 'dur': durationMs},
        {'kind': 'voice', 'media_id': blobId, 'media_key': mkey, 'media_mime': 'audio/m4a', 'duration_ms': durationMs});
  }

  /// ভয়েস মেসেজ চালানোর জন্য ডাউনলোড+ডিক্রিপ্ট (রিস্টোরের পরও কাজ করে)
  Future<File> voiceFile(Map<String, Object?> msg) async {
    final dir = await getTemporaryDirectory();
    final f = File(p.join(dir.path, '${msg['media_id']}.m4a'));
    if (await f.exists()) return f;
    final enc = await api.getBytes('/v1/media/${msg['media_id']}');
    final box = SecretBox.fromConcatenation(enc, nonceLength: 12, macLength: 16);
    final plain = await _aes.decrypt(box, secretKey: SecretKey(base64.decode(msg['media_key'] as String)));
    await f.writeAsBytes(plain);
    return f;
  }

  Future<String?> lookupPhone(String phone) async {
    try {
      final r = await api.get('/v1/users/lookup', q: {'phone': phone});
      await db.upsertContact(r['userId'], phone: phone);
      return r['userId'];
    } catch (_) {
      return null;
    }
  }
}

/// সহজ ভয়েস রেকর্ডার র‍্যাপার
class VoiceRecorder {
  final _rec = AudioRecorder();
  DateTime? _start;
  Future<bool> start() async {
    if (!await _rec.hasPermission()) return false;
    final dir = await getTemporaryDirectory();
    await _rec.start(const RecordConfig(encoder: AudioEncoder.aacLc), path: p.join(dir.path, '${const Uuid().v4()}.m4a'));
    _start = DateTime.now();
    return true;
  }

  Future<(File, int)?> stop() async {
    final path = await _rec.stop();
    if (path == null || _start == null) return null;
    return (File(path), DateTime.now().difference(_start!).inMilliseconds);
  }
}
