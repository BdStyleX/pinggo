import 'dart:convert';
import 'dart:io' show Platform;
import 'dart:typed_data';
import '../api/api_client.dart';
import '../backup/backup_service.dart';
import '../crypto/e2ee.dart';
import '../crypto/recovery_crypto.dart';
import '../db/local_db.dart';
import '../storage/session_store.dart';

/// রেজিস্ট্রেশন, নতুন-ডিভাইস লগইন ও রিকভারি; এবং রিকভারি কোড রোটেশন।
class AccountService {
  AccountService(this.api, this.session, this.e2ee);
  final ApiClient api;
  final SessionStore session;
  final E2eeEngine e2ee;

  Map<String, dynamic> _deviceJson(IdentityKeys k) => {
        'pubkey': ApiClient.b64(k.signingPub),
        'identityKey': ApiClient.b64(k.signingPub),
        'registrationId': k.registrationId,
        'platform': defaultTargetPlatformName(),
      };
  Map<String, dynamic> _prekeysJson(IdentityKeys k) => {
        'signedPrekey': {'keyId': 1, 'publicKey': ApiClient.b64(k.prekeyPub), 'signature': ApiClient.b64(k.prekeySig)},
        'oneTimePrekeys': <Map<String, dynamic>>[], // MVP: sealed-box শুধু signed prekey ব্যবহার করে
      };

  // ── নতুন অ্যাকাউন্ট ──
  Future<Map<String, dynamic>> registerStart(String phone, String email) =>
      api.post('/v1/auth/register/start', {'phone': phone, 'email': email}, auth: false);

  Future<String> registerVerify(String challengeId, String phoneOtp, String emailOtp) async =>
      (await api.post('/v1/auth/register/verify', {'challengeId': challengeId, 'phoneOtp': phoneOtp, 'emailOtp': emailOtp}, auth: false))['registrationToken'];

  /// রিকভারি কোড জেনারেট → ডিরাইভ → রেজিস্টার। ফেরত দেয় ইউজারকে দেখানোর কোড (একবারই)।
  Future<String> registerComplete(String registrationToken) async {
    final keys = await e2ee.generateIdentity();
    final code = RecoveryCrypto.generateCode();
    final salt = RecoveryCrypto.randomBytes(16);
    final mat = await RecoveryCrypto.derive(code, salt, RecoveryCrypto.defaultKdf);
    final r = await api.post('/v1/auth/register/complete', {
      'registrationToken': registrationToken,
      'device': _deviceJson(keys),
      'prekeys': _prekeysJson(keys),
      'recovery': {'verifier': ApiClient.b64(mat.verifier), 'clientSalt': ApiClient.b64(salt), 'kdfParams': RecoveryCrypto.defaultKdf},
    }, auth: false);
    await session.saveAccount(userId: r['userId'], deviceId: r['deviceId'], identity: keys, backupKey: mat.backupKey);
    await session.saveTokens(r['accessToken'], r['refreshToken']);
    return RecoveryCrypto.format(code);
  }

  // ── ফোন হারালে / নতুন ডিভাইসে: OTP + রিকভারি কোড ──
  Future<RecoveryChallenge> recoveryStart(String phone) async {
    final r = await api.post('/v1/auth/recovery/start', {'phone': phone}, auth: false);
    return RecoveryChallenge(r['challengeId'], base64.decode(r['clientSalt']), Map<String, dynamic>.from(r['kdfParams']), r['devOtp']);
  }

  /// সফল হলে নতুন ডিভাইস অ্যাক্টিভ, পুরনো ডিভাইস বাতিল; backupKey রিকভারি কোড থেকে ফেরত আসে।
  Future<void> recoveryVerify(RecoveryChallenge ch, String phoneOtp, String emailOtp, String code) async {
    if (!RecoveryCrypto.isValid(code)) throw const FormatException('রিকভারি কোড ১৬ অক্ষরের হতে হবে');
    final mat = await RecoveryCrypto.derive(code, ch.clientSalt, ch.kdf);
    final keys = await e2ee.generateIdentity(); // নতুন আইডেন্টিটি: কন্টাক্টরা "safety number changed" দেখবে
    final r = await api.post('/v1/auth/recovery/verify', {
      'challengeId': ch.challengeId, 'phoneOtp': phoneOtp, 'emailOtp': emailOtp,
      'verifier': ApiClient.b64(mat.verifier),
      'device': _deviceJson(keys), 'prekeys': _prekeysJson(keys),
    }, auth: false);
    await session.saveAccount(userId: r['userId'], deviceId: r['deviceId'], identity: keys, backupKey: mat.backupKey);
    await session.saveTokens(r['accessToken'], r['refreshToken']);
  }

  /// নতুন রিকভারি কোড সেট। backupKey বদলায়, তাই পুরনো ব্যাকআপ মুছে নতুন কী দিয়ে নতুন snapshot দরকার।
  Future<String> rotateRecoveryCode(LocalDb db, BackupService backup) async {
    final code = RecoveryCrypto.generateCode();
    final salt = RecoveryCrypto.randomBytes(16);
    final mat = await RecoveryCrypto.derive(code, salt, RecoveryCrypto.defaultKdf);
    await api.post('/v1/auth/recovery/rotate', {
      'recovery': {'verifier': ApiClient.b64(mat.verifier), 'clientSalt': ApiClient.b64(salt), 'kdfParams': RecoveryCrypto.defaultKdf},
    });
    await api.delete('/v1/backup');
    await session.saveAccount(userId: session.userId!, deviceId: session.deviceId!, identity: session.identity!, backupKey: mat.backupKey);
    await db.setKv('backup_seq', '0');
    await db.setKv('backup_last_ts', '0');
    await backup.backupNow();
    return RecoveryCrypto.format(code);
  }
}

class RecoveryChallenge {
  RecoveryChallenge(this.challengeId, this.clientSalt, this.kdf, this.devOtp);
  final String challengeId;
  final Uint8List clientSalt;
  final Map<String, dynamic> kdf;
  final dynamic devOtp;
}

String defaultTargetPlatformName() => Platform.isIOS ? 'ios' : 'android';
