# SecureChat (MVP)

E2EE মেসেজিং অ্যাপ: **Flutter** ক্লায়েন্ট + **NestJS** ব্যাকএন্ড + PostgreSQL + Redis।
সার্ভার শুধু ciphertext রিলে করে। রিকভারি কোড দিলে **অ্যাকাউন্ট + চ্যাট + ভয়েস মেসেজ + কল হিস্টরি** ফিরে আসে।

```
securechat/
├─ backend/        NestJS (auth, রিকভারি, key bundle, WebSocket রিলে, এনক্রিপ্টেড ব্যাকআপ, মিডিয়া blob)
│  └─ db/schema.sql
├─ app/            Flutter (SQLCipher, ক্রিপ্টো, ব্যাকআপ/রিস্টোর, UI)
└─ docker-compose.yml
```

## হিস্টরি রিকভারি কীভাবে কাজ করে

```
রিকভারি কোড (১৬ অক্ষর, ৮০ বিট) ──Argon2id(clientSalt)──► root
   root ──HKDF "sc-auth-verifier"──► verifier   → সার্ভারে যায়; সার্ভার pepper+Argon2id দিয়ে আবার হ্যাশ করে রাখে
   root ──HKDF "sc-backup-key"────► backupKey   → কখনো সার্ভারে যায় না
```

- ক্লায়েন্ট চ্যাট/ভয়েস/কল/কন্টাক্ট **gzip → AES-256-GCM (backupKey)** করে সেগমেন্ট হিসেবে আপলোড করে (প্রথমে snapshot, পরে delta; ৪০ delta পর নতুন snapshot + compaction)।
- ভয়েস মেসেজের অডিও আলাদা র‍্যান্ডম কী দিয়ে এনক্রিপ্ট হয়ে `/v1/media/:id`-এ থাকে। `blobId + কী` মেসেজের সাথে ব্যাকআপেও যায়, তাই রিস্টোরের পর ভয়েস মেসেজ আবার চালানো যায়।
- নতুন ফোনে: ফোন OTP + ইমেইল OTP + রিকভারি কোড → সার্ভার verifier মেলায় (৫ বার ভুলে ১ ঘণ্টা, ১০ বারে ২৪ ঘণ্টা লক) → নতুন ডিভাইস অ্যাক্টিভ, পুরনোটি বাতিল → ক্লায়েন্ট একই কোড থেকে `backupKey` বানিয়ে সব সেগমেন্ট ডিক্রিপ্ট ও merge করে (updated_at দিয়ে last-writer-wins; মুছে ফেলা মেসেজ টম্বস্টোন দিয়ে ফেরত আসে না)।
- **কোড হারালে** হিস্টরি গাণিতিকভাবে অপাঠ্য। এটাই zero-knowledge-এর মূল্য।
- নতুন কোড সেট করলে `backupKey` বদলায়, তাই অ্যাপ পুরনো ব্যাকআপ মুছে নতুন কী দিয়ে নতুন snapshot আপলোড করে।

## লোকালে চালানো

```bash
# ১) ইনফ্রা + ব্যাকএন্ড
docker compose up --build -d
docker compose exec api node scripts/migrate.js      # স্কিমা প্রয়োগ

# অথবা সরাসরি:
cd backend && cp .env.example .env && npm install
docker compose up -d postgres redis
DATABASE_URL=postgres://chat:chat@localhost:5432/chat npm run migrate
npm run build && npm start

# ২) Flutter অ্যাপ
cd app
flutter create . --platforms=android,ios     # নেটিভ ফোল্ডার তৈরি (একবার)
flutter pub get
flutter run --dart-define=API_BASE=http://10.0.2.2:3000
```

`DEV_OTP_ECHO=true` থাকলে OTP API রেসপন্সে ফেরত আসে (অ্যাপে টোস্টে দেখায়) এবং সার্ভার কনসোলেও লগ হয়। **প্রোডাকশনে অবশ্যই false**।

Android-এ `AndroidManifest.xml`-এ `INTERNET`, `RECORD_AUDIO` পারমিশন দিন; লোকাল HTTP-র জন্য ডেভেলপমেন্টে `android:usesCleartextTraffic="true"`।

## এই ডেলিভারিতে কী যাচাই হয়েছে, কী হয়নি

| বিষয় | অবস্থা |
|---|---|
| PostgreSQL স্কিমা | ✅ Postgres 16-এ প্রয়োগ করে পরীক্ষিত: দ্বিতীয় active ডিভাইস DB-ই আটকায়, prekey atomic consume কাজ করে |
| রিকভারি + ব্যাকআপ স্কিমের লজিক | ✅ Node-এ একই ডিজাইনে (Argon2id-এর বদলে scrypt) যাচাই: চ্যাট+ভয়েস+কল ফেরে, টম্বস্টোন, ভুল কোড/রিপ্লে/টেম্পারিং ব্যর্থ |
| NestJS ব্যাকএন্ড | ⚠️ **কম্পাইল/রান করা হয়নি**: এই সেশনে npm রেজিস্ট্রি ব্লক ছিল। `tsc` শুধু সিনট্যাক্স পরীক্ষা করেছে (০ সিনট্যাক্স ত্রুটি) |
| Flutter অ্যাপ | ⚠️ **বিল্ড/রান করা হয়নি** (Flutter SDK নেই)। প্রথম `flutter pub get && flutter analyze`-এ ছোটখাটো সংশোধন লাগতে পারে |

## প্রোডাকশনের আগে অবশ্যই করণীয়

1. **E2EE বদলান:** `app/lib/crypto/e2ee.dart` এখন প্লেসহোল্ডার (X25519 + AES-GCM, প্রতি মেসেজে ephemeral কী)। Double Ratchet নেই, তাই forward secrecy সীমিত। libsignal (X3DH + Double Ratchet) দিয়ে `E2eeEngine` ইন্টারফেস বদলান; বাকি অ্যাপ বদলাতে হবে না। একই সাথে one-time prekey ও সার্টিফিকেট/safety-number ভেরিফিকেশন UI যোগ করুন।
2. **OTP ডেলিভারি:** `otp.service.ts`-এ Twilio/Firebase Auth ও SendGrid যুক্ত করুন।
3. **সিক্রেট:** `JWT_SECRET`, `PEPPER` Secret Manager/Cloud KMS থেকে; JWT সাইনিং KMS (HSM)-এ।
4. **Argon2id পারফরম্যান্স:** `cryptography_flutter` নেটিভ ব্যাকএন্ড ব্যবহার করে; mid-range ফোনে m=64MB সময় মাপুন এবং দরকারে `kdfParams` টিউন করুন।
5. **স্টোরেজ:** মিডিয়া blob ও মেইলবক্স যথাক্রমে GCS ও Firestore/Bigtable-এ সরান (এখন লোকাল ডিস্ক ও Postgres)। ব্যাকআপ কোটা (এখন ২GB/ইউজার) পলিসি অনুযায়ী ঠিক করুন।
6. **ছোট ফাঁক:** recovery/login-এ অজানা নম্বরের ক্ষেত্রে verify ধাপে রেসপন্সের পার্থক্য থেকে সীমিত enumeration সম্ভব; `users/lookup` প্রাইভেট কন্টাক্ট ডিসকভারিতে বদলাতে হবে; Play Integrity/App Attest, certificate pinning, push (FCM/APNs), রেট-লিমিট মিডলওয়্যার বাকি।
7. **কলিং:** এই MVP-তে নেই। কল হিস্টরির টেবিল ও ব্যাকআপ প্রস্তুত; LiveKit + TURN যোগ করলে কল হিস্টরিও স্বয়ংক্রিয়ভাবে ব্যাকআপ হবে।
