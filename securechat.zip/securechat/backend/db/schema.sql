-- SecureChat schema. কোনো প্লেইনটেক্সট মেসেজ/রিকভারি কোড/OTP এখানে নেই।
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS citext;

CREATE TABLE IF NOT EXISTS users (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    phone_e164      VARCHAR(16) NOT NULL UNIQUE,
    email           CITEXT      NOT NULL,
    phone_verified  BOOLEAN     NOT NULL DEFAULT FALSE,
    email_verified  BOOLEAN     NOT NULL DEFAULT FALSE,
    status          VARCHAR(16) NOT NULL DEFAULT 'pending'
                    CHECK (status IN ('pending','active','locked','deleted')),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_users_email_active
    ON users(email) WHERE status = 'active';

CREATE TABLE IF NOT EXISTS devices (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    device_pubkey   BYTEA NOT NULL,
    identity_key    BYTEA NOT NULL,
    registration_id INTEGER NOT NULL,
    platform        VARCHAR(10) NOT NULL CHECK (platform IN ('android','ios')),
    push_token      TEXT,
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    revoked_at      TIMESTAMPTZ,
    revoke_reason   VARCHAR(32)
);
-- Single-device: ডাটাবেস লেভেলে গ্যারান্টি
CREATE UNIQUE INDEX IF NOT EXISTS uq_one_active_device_per_user
    ON devices(user_id) WHERE is_active = TRUE;

CREATE TABLE IF NOT EXISTS signed_prekeys (
    device_id   UUID REFERENCES devices(id) ON DELETE CASCADE,
    key_id      INTEGER NOT NULL,
    public_key  BYTEA NOT NULL,
    signature   BYTEA NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (device_id, key_id)
);

CREATE TABLE IF NOT EXISTS one_time_prekeys (
    device_id   UUID REFERENCES devices(id) ON DELETE CASCADE,
    key_id      INTEGER NOT NULL,
    public_key  BYTEA NOT NULL,
    PRIMARY KEY (device_id, key_id)
);

CREATE TABLE IF NOT EXISTS sessions (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id             UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    device_id           UUID NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
    refresh_token_hash  BYTEA NOT NULL UNIQUE,
    family_id           UUID NOT NULL,
    expires_at          TIMESTAMPTZ NOT NULL,
    revoked_at          TIMESTAMPTZ,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id) WHERE revoked_at IS NULL;

-- Zero-knowledge রিকভারি: সার্ভারে শুধু verifier-এর Argon2id হ্যাশ
CREATE TABLE IF NOT EXISTS recovery_keys (
    user_id         UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    verifier_hash   TEXT   NOT NULL,
    client_salt     BYTEA  NOT NULL,
    kdf_params      JSONB  NOT NULL,
    failed_attempts INTEGER NOT NULL DEFAULT 0,
    locked_until    TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    rotated_at      TIMESTAMPTZ
);

-- অফলাইন মেসেজ কিউ (শুধু ciphertext)। প্রোডাকশনে Firestore-এ সরানো যায়।
CREATE TABLE IF NOT EXISTS mailbox (
    seq                BIGSERIAL PRIMARY KEY,
    id                 UUID NOT NULL UNIQUE,
    recipient_user_id  UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    sender_user_id     UUID NOT NULL,
    ct                 BYTEA NOT NULL,
    msg_type           SMALLINT NOT NULL DEFAULT 1,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    expires_at         TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_mailbox_recipient ON mailbox(recipient_user_id, seq);

-- এনক্রিপ্টেড ব্যাকআপ সেগমেন্ট (চ্যাট, ভয়েস মেসেজ রেফারেন্স, কল হিস্টরি)
-- সার্ভার শুধু অন্ধ blob রাখে; কী থাকে রিকভারি কোড থেকে ডিরাইভ হয়ে ক্লায়েন্টে।
CREATE TABLE IF NOT EXISTS backup_segments (
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    seq         BIGINT NOT NULL,
    kind        VARCHAR(8) NOT NULL CHECK (kind IN ('snapshot','delta')),
    blob        BYTEA NOT NULL,
    sha256      BYTEA NOT NULL,
    size_bytes  INTEGER NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (user_id, seq)
);

-- এনক্রিপ্টেড মিডিয়া/ভয়েস ব্লব (ডিস্কে থাকে; এখানে শুধু মালিকানা মেটাডেটা)
CREATE TABLE IF NOT EXISTS media_blobs (
    id          UUID PRIMARY KEY,
    owner_id    UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    size_bytes  BIGINT NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS audit_events (
    id          BIGSERIAL PRIMARY KEY,
    user_id     UUID,
    event_type  VARCHAR(48) NOT NULL,
    meta        JSONB,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
