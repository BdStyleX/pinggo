import { BadRequestException, Body, Controller, Delete, Get, Headers, NotFoundException, Param, Post, Put, Req, Res, UseGuards } from '@nestjs/common';
import { createHash } from 'crypto';
import { Auth, AuthGuard } from '../common/auth.guard';
import { AccessClaims } from '../common/token.service';
import { Db } from '../common/infra';

const MAX_SEGMENT = 32 * 1024 * 1024;
const MAX_TOTAL_PER_USER = 2 * 1024 * 1024 * 1024; // 2GB; প্ল্যান অনুযায়ী বদলান

/**
 * এনক্রিপ্টেড হিস্টরি ব্যাকআপ (চ্যাট, ভয়েস মেসেজ রেফারেন্স, কল হিস্টরি)।
 * সার্ভার শুধু অন্ধ ciphertext রাখে। ডিক্রিপশন কী (backup_key) রিকভারি কোড থেকে ক্লায়েন্টে ডিরাইভ হয়।
 * ডাউনলোডের জন্য শুধু লগইন লাগে: কী ছাড়া blob অর্থহীন।
 */
@Controller('v1/backup')
@UseGuards(AuthGuard)
export class BackupController {
  constructor(private db: Db) {}

  @Get('manifest')
  async manifest(@Auth() a: AccessClaims) {
    const rows = await this.db.q('SELECT seq,kind,size_bytes,encode(sha256,\'hex\') AS sha256,created_at FROM backup_segments WHERE user_id=$1 ORDER BY seq', [a.sub]);
    return { segments: rows.map((r) => ({ seq: Number(r.seq), kind: r.kind, size: r.size_bytes, sha256: r.sha256, createdAt: r.created_at })) };
  }

  @Put('segments/:seq')
  async put(@Auth() a: AccessClaims, @Param('seq') seqStr: string, @Headers('x-segment-kind') kind: string, @Req() req: any) {
    const seq = Number(seqStr);
    const body: Buffer = req.body;
    if (!Number.isSafeInteger(seq) || seq < 1) throw new BadRequestException('bad_seq');
    if (!['snapshot', 'delta'].includes(kind)) throw new BadRequestException('bad_kind');
    if (!Buffer.isBuffer(body) || body.length < 29 || body.length > MAX_SEGMENT) throw new BadRequestException('bad_body');
    const used = (await this.db.q('SELECT COALESCE(sum(size_bytes),0)::bigint AS n FROM backup_segments WHERE user_id=$1 AND seq<>$2', [a.sub, seq]))[0].n;
    if (Number(used) + body.length > MAX_TOTAL_PER_USER) throw new BadRequestException('quota_exceeded');
    const sha = createHash('sha256').update(body).digest();
    // সেগমেন্ট immutable: একই seq আবার এলে একই বাইটস হলে OK (idempotent), নইলে 409
    const ex = (await this.db.q('SELECT sha256 FROM backup_segments WHERE user_id=$1 AND seq=$2', [a.sub, seq]))[0];
    if (ex) {
      if (Buffer.compare(ex.sha256, sha) === 0) return { ok: true, duplicate: true };
      throw new BadRequestException('segment_exists_with_different_content');
    }
    await this.db.q('INSERT INTO backup_segments(user_id,seq,kind,blob,sha256,size_bytes) VALUES($1,$2,$3,$4,$5,$6)', [a.sub, seq, kind, body, sha, body.length]);
    return { ok: true };
  }

  @Get('segments/:seq')
  async get(@Auth() a: AccessClaims, @Param('seq') seqStr: string, @Res() res: any) {
    const r = (await this.db.q('SELECT blob FROM backup_segments WHERE user_id=$1 AND seq=$2', [a.sub, Number(seqStr)]))[0];
    if (!r) throw new NotFoundException();
    res.setHeader('Content-Type', 'application/octet-stream');
    res.send(r.blob);
  }

  /** নতুন snapshot আপলোডের পর পুরনো সেগমেন্ট মুছে compaction */
  @Post('compact')
  async compact(@Auth() a: AccessClaims, @Body() b: { keepFromSeq: number }) {
    const k = Number(b?.keepFromSeq);
    if (!Number.isSafeInteger(k)) throw new BadRequestException();
    const snap = await this.db.q(`SELECT 1 FROM backup_segments WHERE user_id=$1 AND seq=$2 AND kind='snapshot'`, [a.sub, k]);
    if (!snap.length) throw new BadRequestException('keepFromSeq_must_be_snapshot');
    await this.db.q('DELETE FROM backup_segments WHERE user_id=$1 AND seq<$2', [a.sub, k]);
    return { ok: true };
  }

  @Delete()
  async reset(@Auth() a: AccessClaims) {
    await this.db.q('DELETE FROM backup_segments WHERE user_id=$1', [a.sub]);
    return { ok: true };
  }
}
