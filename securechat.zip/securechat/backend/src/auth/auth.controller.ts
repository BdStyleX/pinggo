import { Body, Controller, Delete, Post, UseGuards } from '@nestjs/common';
import { Auth, AuthGuard } from '../common/auth.guard';
import { AccessClaims } from '../common/token.service';
import { AuthService } from './auth.service';

@Controller('v1/auth')
export class AuthController {
  constructor(private s: AuthService) {}

  @Post('register/start') registerStart(@Body() b: any) { return this.s.registerStart(b.phone, b.email); }
  @Post('register/verify') registerVerify(@Body() b: any) { return this.s.registerVerify(b.challengeId, b.phoneOtp, b.emailOtp); }
  @Post('register/complete')
  registerComplete(@Body() b: any) { return this.s.registerComplete(b.registrationToken, b.device, b.prekeys, b.recovery); }

  @Post('login/start') loginStart(@Body() b: any) { return this.s.loginStart(b.phone); }
  @Post('login/verify')
  loginVerify(@Body() b: any) { return this.s.loginVerify(b.challengeId, b.phoneOtp, b.emailOtp, b.device, b.prekeys); }

  @Post('recovery/start') recoveryStart(@Body() b: any) { return this.s.recoveryStart(b.phone); }
  @Post('recovery/verify')
  recoveryVerify(@Body() b: any) { return this.s.recoveryVerify(b.challengeId, b.phoneOtp, b.emailOtp, b.verifier, b.device, b.prekeys); }

  @Post('recovery/rotate') @UseGuards(AuthGuard)
  recoveryRotate(@Auth() a: AccessClaims, @Body() b: any) { return this.s.recoveryRotate(a.sub, b.recovery); }

  @Post('token/refresh') refresh(@Body() b: any) { return this.s.refresh(b.refreshToken); }
  @Post('logout') @UseGuards(AuthGuard) logout(@Auth() a: AccessClaims) { return this.s.logout(a.sub, a.sid); }
  @Delete('account') @UseGuards(AuthGuard) del(@Auth() a: AccessClaims) { return this.s.deleteAccount(a.sub); }
}
