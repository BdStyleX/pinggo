import { BadRequestException, ConflictException, HttpException, HttpStatus, Injectable, NotFoundException, UnauthorizedException } from '@nestjs/common';
import * as argon2 from 'argon2';
import { createHmac, randomBytes } from 'crypto';
import { PoolClient } from 'pg';
import { Db, RedisService, cfg } from '../common/infra';
import { TokenService } from '../common/token.service';
import { OtpService } from './otp.service';

export interface DeviceInput {
  pubkey: string; // b64
  identityKey: string; // b64
  registrationId: number;
  platform: 'android' | 'ios';
  pushToken?: string;
}
export interface PrekeyInput {
  signedPrekey: { keyId: number; publicKey: string; signature: string };
  oneTimePrekeys: { keyId: number; publicKey: string }[];
}
export interface RecoveryInput {
  verifier: string; // b64 (ক্লায়েন্টে Argon2id+HKDF থেকে ডিরাইভড)
  clientSalt: string; // b64
  kdfParams: { alg: 'argon2id'; m: number; t: number; p: number };
}

const b = (s: string) => Buffer.from(s, 'base64');
const PHONE_RE = /^\+[1-9]\d{6,14}$/;
const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
const DEFAULT_KDF = { alg: 'argon2id', m: 65536, t: 3, p: 4 };

@Injectable()
export class AuthService {
  constructor(private db: Db, private redis: RedisService, private tokens: TokenService, private otp: OtpService) {}

  // ───────────── রেজিস্ট্রেশন ─────────────
  async registerStart(phone: string, email: string) {
    if (!PHONE_RE.test(phone ?? '') || !EMAIL_RE.test(email ?? '')) throw new BadRequestException('invalid_phone_or_email');
    const existing = await this.db.q('SELECT id,status FROM users WHERE phone_e164=$1', [phone]);
    if (existing[0]?.status === 'active') throw new ConflictException('already_registered_use_login_or_recovery');
    const emailTaken = await this.db.q(`SELECT 1 FROM users WHERE email=$1 AND status='active'`, [email]);
    if (emailTaken.length) throw new ConflictException('email_in_use');

    const userId = existing[0]
      ? (await this.db.q('UPDATE users SET email=$2, updated_at=now() WHERE id=$1 RETURNING id', [existing[0].id, email]))[0].id
      : (await this.db.q('INSERT INTO users(phone_e164,email) VALUES($1,$2) RETURNING id', [phone, email]))[0].id;

    const challengeId = this.tokens.newId();
    await this.redis.client.set(`chal:${challengeId}`, JSON.stringify({ purpose: 'register', userId, phone, email }), 'EX', 600);
    const dev = await this.otp.issue(challengeId, phone, email);
    return { challengeId, ...(dev ? { devOtp: dev } : {}) };
  }

  async registerVerify(challengeId: string, phoneOtp: string, emailOtp: string) {
    const ch = await this.loadChallenge(challengeId, 'register');
    await this.otp.verify(challengeId, phoneOtp, emailOtp);
    await this.redis.client.del(`chal:${challengeId}`);
    const registrationToken = this.tokens.signPurpose('register_complete', { userId: ch.userId }, '15m');
    return { registrationToken };
  }

  async registerComplete(registrationToken: string, device: DeviceInput, prekeys: PrekeyInput, recovery: RecoveryInput) {
    const { userId } = this.tokens.verifyPurpose<{ userId: string }>(registrationToken, 'register_complete');
    this.validateDevice(device, prekeys);
    this.validateRecovery(recovery);
    const verifierHash = await this.hashVerifier(recovery.verifier);

    const result = await this.db.tx(async (c) => {
      const u = (await c.query('SELECT status FROM users WHERE id=$1 FOR UPDATE', [userId])).rows[0];
      if (!u) throw new NotFoundException();
      if (u.status === 'active') throw new ConflictException('already_registered');
      await c.query(`UPDATE users SET status='active', phone_verified=true, email_verified=true, updated_at=now() WHERE id=$1`, [userId]);
      await c.query(
        `INSERT INTO recovery_keys(user_id,verifier_hash,client_salt,kdf_params) VALUES($1,$2,$3,$4)`,
        [userId, verifierHash, b(recovery.clientSalt), recovery.kdfParams],
      );
      return this.installDevice(c, userId, device, prekeys, 'register');
    });
    return this.commitEffects(result);
  }

  // ───────────── নতুন ডিভাইসে লগইন (OTP) ─────────────
  async loginStart(phone: string) {
    return this.otpChallengeForExisting('login', phone);
  }

  async loginVerify(challengeId: string, phoneOtp: string, emailOtp: string, device: DeviceInput, prekeys: PrekeyInput) {
    const ch = await this.loadChallenge(challengeId, 'login');
    this.validateDevice(device, prekeys);
    await this.otp.verify(challengeId, phoneOtp, emailOtp);
    await this.redis.client.del(`chal:${challengeId}`);
    return this.commitEffects(await this.db.tx((c) => this.installDevice(c, ch.userId, device, prekeys, 'login_new_device')));
  }

  // ───────────── রিকভারি (OTP + রিকভারি কোড) ─────────────
  async recoveryStart(phone: string) {
    const r = await this.otpChallengeForExisting('recovery', phone);
    // enumeration এড়াতে অজানা নম্বরের জন্যও ডিটারমিনিস্টিক নকল salt দিই
    const row = (await this.db.q(`SELECT rk.client_salt, rk.kdf_params FROM recovery_keys rk JOIN users u ON u.id=rk.user_id WHERE u.phone_e164=$1 AND u.status='active'`, [phone]))[0];
    const fake = createHmac('sha256', cfg.pepper()).update(`salt|${phone}`).digest().subarray(0, 16);
    return { ...r, clientSalt: (row?.client_salt ?? fake).toString('base64'), kdfParams: row?.kdf_params ?? DEFAULT_KDF };
  }

  async recoveryVerify(challengeId: string, phoneOtp: string, emailOtp: string, verifier: string, device: DeviceInput, prekeys: PrekeyInput) {
    const ch = await this.loadChallenge(challengeId, 'recovery');
    if (!ch.userId) throw new UnauthorizedException('recovery_failed');
    this.validateDevice(device, prekeys);

    const rk = (await this.db.q('SELECT * FROM recovery_keys WHERE user_id=$1', [ch.userId]))[0];
    if (!rk) throw new UnauthorizedException('recovery_failed');
    if (rk.locked_until && new Date(rk.locked_until) > new Date()) {
      throw new HttpException({ error: 'recovery_locked', until: rk.locked_until }, HttpStatus.TOO_MANY_REQUESTS);
    }
    await this.otp.verify(challengeId, phoneOtp, emailOtp);

    const ok = await this.verifyVerifier(rk.verifier_hash, verifier ?? '');
    if (!ok) {
      const n = rk.failed_attempts + 1;
      // ৫ বার ভুলে ১ ঘণ্টা, ১০ বার ভুলে ২৪ ঘণ্টা লক
      const lockMs = n >= 10 ? 24 * 3600e3 : n >= 5 ? 3600e3 : 0;
      await this.db.q('UPDATE recovery_keys SET failed_attempts=$2, locked_until=$3 WHERE user_id=$1', [ch.userId, n, lockMs ? new Date(Date.now() + lockMs) : null]);
      await this.audit(ch.userId, 'recovery_failed', { attempts: n });
      throw new UnauthorizedException('recovery_failed');
    }
    await this.db.q('UPDATE recovery_keys SET failed_attempts=0, locked_until=NULL WHERE user_id=$1', [ch.userId]);
    await this.redis.client.del(`chal:${challengeId}`);
    return this.commitEffects(await this.db.tx((c) => this.installDevice(c, ch.userId, device, prekeys, 'recovery')));
  }

  /** লগইন অবস্থায় নতুন রিকভারি কোড সেট (পুরনো কোড বাতিল) */
  async recoveryRotate(userId: string, recovery: RecoveryInput) {
    this.validateRecovery(recovery);
    const h = await this.hashVerifier(recovery.verifier);
    await this.db.q(
      `UPDATE recovery_keys SET verifier_hash=$2, client_salt=$3, kdf_params=$4, failed_attempts=0, locked_until=NULL, rotated_at=now() WHERE user_id=$1`,
      [userId, h, b(recovery.clientSalt), recovery.kdfParams],
    );
    await this.audit(userId, 'recovery_rotated', {});
    return { ok: true };
  }

  // ───────────── টোকেন রিফ্রেশ (rotation + reuse detection) ─────────────
  async refresh(refreshToken: string) {
    const hash = this.tokens.hashRefresh(refreshToken ?? '');
    return this.db.tx(async (c) => {
      const s = (await c.query('SELECT * FROM sessions WHERE refresh_token_hash=$1 FOR UPDATE', [hash])).rows[0];
      if (!s) throw new UnauthorizedException('invalid_refresh');
      if (s.revoked_at) {
        // পুরনো টোকেন পুনর্ব্যবহার = সম্ভাব্য চুরি → পুরো family revoke
        await c.query('UPDATE sessions SET revoked_at=now() WHERE family_id=$1 AND revoked_at IS NULL', [s.family_id]);
        await this.audit(s.user_id, 'refresh_reuse_detected', { family: s.family_id });
        throw new UnauthorizedException('refresh_reuse');
      }
      if (new Date(s.expires_at) < new Date()) throw new UnauthorizedException('refresh_expired');
      const dev = (await c.query('SELECT is_active FROM devices WHERE id=$1', [s.device_id])).rows[0];
      if (!dev?.is_active) throw new UnauthorizedException('SESSION_REPLACED');
      await c.query('UPDATE sessions SET revoked_at=now() WHERE id=$1', [s.id]);
      return this.issueSession(c, s.user_id, s.device_id, s.family_id);
    });
  }

  async logout(userId: string, sessionId: string) {
    await this.db.q('UPDATE sessions SET revoked_at=now() WHERE id=$1 AND user_id=$2', [sessionId, userId]);
    return { ok: true };
  }

  async deleteAccount(userId: string) {
    await this.db.tx(async (c) => {
      await c.query(`UPDATE users SET status='deleted', updated_at=now() WHERE id=$1`, [userId]);
      await c.query('UPDATE devices SET is_active=false, revoked_at=now(), revoke_reason=$2 WHERE user_id=$1 AND is_active', [userId, 'account_deleted']);
      await c.query('UPDATE sessions SET revoked_at=now() WHERE user_id=$1 AND revoked_at IS NULL', [userId]);
      await c.query('DELETE FROM backup_segments WHERE user_id=$1', [userId]);
      await c.query('DELETE FROM mailbox WHERE recipient_user_id=$1', [userId]);
    });
    await this.redis.client.del(`active_device:${userId}`);
    await this.redis.client.publish('kick', JSON.stringify({ userId, deviceId: null }));
    return { ok: true };
  }

  // ───────────── অভ্যন্তরীণ ─────────────
  /** এক ট্রানজ্যাকশনে: পুরনো ডিভাইস/সেশন revoke → নতুন ডিভাইস + prekey → নতুন সেশন */
  private async installDevice(c: PoolClient, userId: string, d: DeviceInput, pk: PrekeyInput, reason: string) {
    await c.query('UPDATE devices SET is_active=false, revoked_at=now(), revoke_reason=$2 WHERE user_id=$1 AND is_active', [userId, reason]);
    await c.query('UPDATE sessions SET revoked_at=now() WHERE user_id=$1 AND revoked_at IS NULL', [userId]);
    const deviceId = (
      await c.query(
        `INSERT INTO devices(user_id,device_pubkey,identity_key,registration_id,platform,push_token) VALUES($1,$2,$3,$4,$5,$6) RETURNING id`,
        [userId, b(d.pubkey), b(d.identityKey), d.registrationId, d.platform, d.pushToken ?? null],
      )
    ).rows[0].id;
    await c.query('INSERT INTO signed_prekeys(device_id,key_id,public_key,signature) VALUES($1,$2,$3,$4)', [
      deviceId, pk.signedPrekey.keyId, b(pk.signedPrekey.publicKey), b(pk.signedPrekey.signature),
    ]);
    for (const k of pk.oneTimePrekeys) {
      await c.query('INSERT INTO one_time_prekeys(device_id,key_id,public_key) VALUES($1,$2,$3)', [deviceId, k.keyId, b(k.publicKey)]);
    }
    // পুরনো ডিভাইসের জন্য জমে থাকা মেইলবক্স পুরনো কী দিয়ে এনক্রিপ্টেড; নতুন ডিভাইসে পড়া যাবে না
    await c.query('DELETE FROM mailbox WHERE recipient_user_id=$1', [userId]);
    await c.query('INSERT INTO audit_events(user_id,event_type,meta) VALUES($1,$2,$3)', [userId, 'device_replaced', { reason, deviceId }]);
    const session = await this.issueSession(c, userId, deviceId, this.tokens.newId());
    return { userId, deviceId, ...session };
  }

  /** ট্রানজ্যাকশন কমিটের পর: Redis active-device আপডেট + পুরনো সকেট kick */
  private async commitEffects<T extends { userId: string; deviceId: string }>(r: T): Promise<T> {
    await this.redis.client.set(`active_device:${r.userId}`, r.deviceId, 'EX', 3600);
    await this.redis.client.publish('kick', JSON.stringify({ userId: r.userId, deviceId: r.deviceId }));
    return r;
  }

  private async issueSession(c: PoolClient, userId: string, deviceId: string, familyId: string) {
    const sid = this.tokens.newId();
    const rt = this.tokens.newRefreshToken();
    await c.query(
      `INSERT INTO sessions(id,user_id,device_id,refresh_token_hash,family_id,expires_at) VALUES($1,$2,$3,$4,$5, now() + interval '30 days')`,
      [sid, userId, deviceId, rt.hash, familyId],
    );
    return { accessToken: this.tokens.signAccess({ sub: userId, did: deviceId, sid }), refreshToken: rt.raw, expiresIn: 900 };
  }

  private async otpChallengeForExisting(purpose: 'login' | 'recovery', phone: string) {
    if (!PHONE_RE.test(phone ?? '')) throw new BadRequestException('invalid_phone');
    const u = (await this.db.q(`SELECT id,email FROM users WHERE phone_e164=$1 AND status='active'`, [phone]))[0];
    const challengeId = this.tokens.newId();
    // enumeration এড়াতে অজানা নম্বরেও একই আকৃতির রেসপন্স; OTP আসলে পাঠানো হয় না
    await this.redis.client.set(`chal:${challengeId}`, JSON.stringify({ purpose, userId: u?.id ?? null }), 'EX', 600);
    let dev;
    if (u) dev = await this.otp.issue(challengeId, phone, u.email);
    return { challengeId, ...(dev ? { devOtp: dev } : {}) };
  }

  private async loadChallenge(id: string, purpose: string) {
    const raw = await this.redis.client.get(`chal:${id}`);
    if (!raw) throw new HttpException('challenge_expired', HttpStatus.GONE);
    const ch = JSON.parse(raw);
    if (ch.purpose !== purpose) throw new UnauthorizedException('challenge_mismatch');
    return ch;
  }

  /** verifier-কে pepper দিয়ে HMAC করে তারপর Argon2id: DB লিক হলেও pepper ছাড়া অফলাইন ব্রুটফোর্স অসম্ভব */
  private async hashVerifier(verifierB64: string) {
    const peppered = createHmac('sha256', cfg.pepper()).update(b(verifierB64)).digest();
    return argon2.hash(peppered, { type: argon2.argon2id, memoryCost: 19456, timeCost: 2, parallelism: 1 });
  }
  private async verifyVerifier(hash: string, verifierB64: string) {
    try {
      const peppered = createHmac('sha256', cfg.pepper()).update(b(verifierB64)).digest();
      return await argon2.verify(hash, peppered);
    } catch {
      return false;
    }
  }

  private validateDevice(d: DeviceInput, p: PrekeyInput) {
    if (!d?.pubkey || !d?.identityKey || !Number.isInteger(d.registrationId) || !['android', 'ios'].includes(d.platform)) throw new BadRequestException('invalid_device');
    if (!p?.signedPrekey?.publicKey || !p.signedPrekey.signature || !Array.isArray(p.oneTimePrekeys) || p.oneTimePrekeys.length > 200) throw new BadRequestException('invalid_prekeys');
  }
  private validateRecovery(r: RecoveryInput) {
    if (!r?.verifier || b(r.verifier).length !== 32 || !r.clientSalt || b(r.clientSalt).length < 16) throw new BadRequestException('invalid_recovery');
    if (r.kdfParams?.alg !== 'argon2id' || r.kdfParams.m < 19456 || r.kdfParams.t < 2) throw new BadRequestException('weak_kdf_params');
  }
  private audit(userId: string, type: string, meta: object) {
    return this.db.q('INSERT INTO audit_events(user_id,event_type,meta) VALUES($1,$2,$3)', [userId, type, meta]);
  }
}
