import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { createHmac, randomInt, timingSafeEqual } from 'crypto';
import { RedisService, cfg } from '../common/infra';

type Channel = 'sms' | 'email';

/** ডেলিভারি অ্যাডাপ্টার। প্রোডাকশনে Twilio/Firebase Auth ও SendGrid এখানে বসবে। */
@Injectable()
export class OtpService {
  constructor(private redis: RedisService) {}

  private h(code: string, challengeId: string, ch: Channel) {
    return createHmac('sha256', cfg.pepper()).update(`${challengeId}|${ch}|${code}`).digest();
  }

  /** দুটি চ্যানেলে OTP পাঠায় (এখানে কনসোলে লগ)। dev echo চালু থাকলে কোড ফেরত দেয়। */
  async issue(challengeId: string, phone: string, email: string) {
    await this.rateLimit(`otp_rl:${phone}`, 5, 3600);
    await this.rateLimit(`otp_rl:${email.toLowerCase()}`, 5, 3600);
    const codes: Record<Channel, string> = {
      sms: String(randomInt(0, 1_000_000)).padStart(6, '0'),
      email: String(randomInt(0, 1_000_000)).padStart(6, '0'),
    };
    const key = `otp:${challengeId}`;
    await this.redis.client
      .multi()
      .hset(key, { sms: this.h(codes.sms, challengeId, 'sms').toString('hex'), email: this.h(codes.email, challengeId, 'email').toString('hex'), attempts: 0 })
      .expire(key, 300)
      .exec();
    // TODO(prod): SMS provider + SendGrid। কোড কখনো লগে রাখবেন না।
    if (process.env.NODE_ENV !== 'production') {
      console.log(`[dev-otp] ${challengeId} sms(${phone})=${codes.sms} email(${email})=${codes.email}`);
    }
    return cfg.devOtpEcho() ? codes : undefined;
  }

  async verify(challengeId: string, smsCode: string, emailCode: string): Promise<void> {
    const key = `otp:${challengeId}`;
    const attempts = await this.redis.client.hincrby(key, 'attempts', 1);
    if (attempts > 5) {
      await this.redis.client.del(key);
      throw new HttpException('otp_attempts_exceeded', HttpStatus.TOO_MANY_REQUESTS);
    }
    const stored = await this.redis.client.hgetall(key);
    if (!stored.sms || !stored.email) throw new HttpException('otp_expired', HttpStatus.GONE);
    const ok1 = this.eq(Buffer.from(stored.sms, 'hex'), this.h(String(smsCode), challengeId, 'sms'));
    const ok2 = this.eq(Buffer.from(stored.email, 'hex'), this.h(String(emailCode), challengeId, 'email'));
    if (!(ok1 && ok2)) throw new HttpException('otp_invalid', HttpStatus.UNAUTHORIZED);
    await this.redis.client.del(key); // একবার ব্যবহারযোগ্য
  }

  private eq(a: Buffer, b: Buffer) {
    return a.length === b.length && timingSafeEqual(a, b);
  }

  private async rateLimit(key: string, max: number, windowSec: number) {
    const n = await this.redis.client.incr(key);
    if (n === 1) await this.redis.client.expire(key, windowSec);
    if (n > max) throw new HttpException('rate_limited', HttpStatus.TOO_MANY_REQUESTS);
  }
}
