import 'reflect-metadata';
import { NestFactory } from '@nestjs/core';
import { WsAdapter } from '@nestjs/platform-ws';
import { json, raw } from 'express';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule, { bodyParser: false });
  app.use(json({ limit: '1mb' }));
  // এনক্রিপ্টেড blob (মিডিয়া/ব্যাকআপ সেগমেন্ট) র‍্যাও বাইটস হিসেবে আসে
  app.use(raw({ type: 'application/octet-stream', limit: '100mb' }));
  app.useWebSocketAdapter(new WsAdapter(app));
  app.enableShutdownHooks();
  await app.listen(Number(process.env.PORT ?? 3000), '0.0.0.0');
}
bootstrap();
