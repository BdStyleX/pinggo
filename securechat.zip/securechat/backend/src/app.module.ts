import { Module } from '@nestjs/common';
import { CommonModule } from './common/common.module';
import { AuthController } from './auth/auth.controller';
import { AuthService } from './auth/auth.service';
import { OtpService } from './auth/otp.service';
import { KeysController } from './keys/keys.controller';
import { ChatGateway } from './chat/chat.gateway';
import { BackupController } from './backup/backup.controller';
import { MediaController } from './media/media.controller';

@Module({
  imports: [CommonModule],
  controllers: [AuthController, KeysController, BackupController, MediaController],
  providers: [AuthService, OtpService, ChatGateway],
})
export class AppModule {}
