import { Injectable, OnModuleDestroy } from '@nestjs/common';
import { Pool, PoolClient, QueryResultRow } from 'pg';
import Redis from 'ioredis';

export const cfg = {
  jwtSecret: () => process.env.JWT_SECRET ?? 'dev-secret-dev-secret-dev-secret-00',
  pepper: () => process.env.PEPPER ?? 'dev-pepper',
  devOtpEcho: () => process.env.DEV_OTP_ECHO === 'true',
  mediaDir: () => process.env.MEDIA_DIR ?? './data/media',
};

@Injectable()
export class Db implements OnModuleDestroy {
  readonly pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 20 });
  async q<T extends QueryResultRow = any>(text: string, params: any[] = []): Promise<T[]> {
    return (await this.pool.query<T>(text, params)).rows;
  }
  async tx<T>(fn: (c: PoolClient) => Promise<T>): Promise<T> {
    const c = await this.pool.connect();
    try {
      await c.query('BEGIN');
      const r = await fn(c);
      await c.query('COMMIT');
      return r;
    } catch (e) {
      await c.query('ROLLBACK');
      throw e;
    } finally {
      c.release();
    }
  }
  onModuleDestroy() {
    return this.pool.end();
  }
}

@Injectable()
export class RedisService implements OnModuleDestroy {
  readonly client = new Redis(process.env.REDIS_URL ?? 'redis://localhost:6379');
  /** pub/sub-এর জন্য আলাদা কানেকশন লাগে */
  newConnection() {
    return this.client.duplicate();
  }
  onModuleDestroy() {
    this.client.disconnect();
  }
}

