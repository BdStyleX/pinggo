import { Injectable, UnauthorizedException } from '@nestjs/common';
import * as jwt from 'jsonwebtoken';
import { createHash, randomBytes, randomUUID } from 'crypto';
import { Db, RedisService, cfg } from './infra';

export interface AccessClaims {
  sub: string; // user id
  did: string; // device id
  sid: string; // session id
}

@Injectable()
export class TokenService {
  constructor(private db: Db, private redis: RedisService) {}

  signAccess(c: AccessClaims) {
    return jwt.sign(c, cfg.jwtSecret(), { algorithm: 'HS256', expiresIn: '15m' });
  }

  signPurpose(purpose: string, payload: object, ttl: string) {
    return jwt.sign({ ...payload, purpose }, cfg.jwtSecret(), { algorithm: 'HS256', expiresIn: ttl as any });
  }

  verifyPurpose<T = any>(token: string, purpose: string): T {
    try {
      const p: any = jwt.verify(token, cfg.jwtSecret(), { algorithms: ['HS256'] });
      if (p.purpose !== purpose) throw new Error('purpose');
      return p;
    } catch {
      throw new UnauthorizedException('invalid_token');
    }
  }

  /** অ্যাক্সেস টোকেন যাচাই + এই ডিভাইসটিই এখনো একমাত্র active ডিভাইস কি না */
  async verifyAccess(token: string): Promise<AccessClaims> {
    let p: any;
    try {
      p = jwt.verify(token, cfg.jwtSecret(), { algorithms: ['HS256'] });
    } catch {
      throw new UnauthorizedException('invalid_token');
    }
    if (!p.sub || !p.did || p.purpose) throw new UnauthorizedException('invalid_token');
    const key = `active_device:${p.sub}`;
    let active = await this.redis.client.get(key);
    if (!active) {
      const rows = await this.db.q('SELECT id FROM devices WHERE user_id=$1 AND is_active', [p.sub]);
      active = rows[0]?.id ?? null;
      if (active) await this.redis.client.set(key, active, 'EX', 3600);
    }
    if (active !== p.did) throw new UnauthorizedException('SESSION_REPLACED');
    return { sub: p.sub, did: p.did, sid: p.sid };
  }

  newRefreshToken() {
    const raw = randomBytes(32).toString('base64url');
    return { raw, hash: this.hashRefresh(raw) };
  }
  hashRefresh(raw: string) {
    return createHash('sha256').update(raw).digest();
  }
  newId() {
    return randomUUID();
  }
}
