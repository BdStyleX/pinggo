import { Global, Module } from '@nestjs/common';
import { Db, RedisService } from './infra';
import { AuthGuard } from './auth.guard';
import { TokenService } from './token.service';

export { Db, RedisService, cfg } from './infra';

@Global()
@Module({
  providers: [Db, RedisService, TokenService, AuthGuard],
  exports: [Db, RedisService, TokenService, AuthGuard],
})
export class CommonModule {}
