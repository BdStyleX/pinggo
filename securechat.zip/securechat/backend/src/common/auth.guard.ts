import { CanActivate, ExecutionContext, Injectable, UnauthorizedException, createParamDecorator } from '@nestjs/common';
import { TokenService, AccessClaims } from './token.service';

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private tokens: TokenService) {}
  async canActivate(ctx: ExecutionContext): Promise<boolean> {
    const req = ctx.switchToHttp().getRequest();
    const h: string = req.headers['authorization'] ?? '';
    if (!h.startsWith('Bearer ')) throw new UnauthorizedException('missing_token');
    req.auth = await this.tokens.verifyAccess(h.slice(7));
    return true;
  }
}

export const Auth = createParamDecorator((_d: unknown, ctx: ExecutionContext): AccessClaims => {
  return ctx.switchToHttp().getRequest().auth;
});
