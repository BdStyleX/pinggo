import { BadRequestException, Body, Controller, Get, NotFoundException, Param, ParseUUIDPipe, Put, Query, UseGuards } from '@nestjs/common';
import { Auth, AuthGuard } from '../common/auth.guard';
import { AccessClaims } from '../common/token.service';
import { Db } from '../common/infra';

const b = (s: string) => Buffer.from(s, 'base64');

@Controller('v1')
@UseGuards(AuthGuard)
export class KeysController {
  constructor(private db: Db) {}

  @Put('keys/prekeys')
  async putPrekeys(@Auth() a: AccessClaims, @Body() body: { oneTimePrekeys: { keyId: number; publicKey: string }[] }) {
    if (!Array.isArray(body.oneTimePrekeys) || body.oneTimePrekeys.length > 200) throw new BadRequestException();
    for (const k of body.oneTimePrekeys) {
      await this.db.q('INSERT INTO one_time_prekeys(device_id,key_id,public_key) VALUES($1,$2,$3) ON CONFLICT DO NOTHING', [a.did, k.keyId, b(k.publicKey)]);
    }
    const n = (await this.db.q('SELECT count(*)::int AS n FROM one_time_prekeys WHERE device_id=$1', [a.did]))[0].n;
    return { remaining: n };
  }

  @Put('keys/signed-prekey')
  async putSigned(@Auth() a: AccessClaims, @Body() k: { keyId: number; publicKey: string; signature: string }) {
    await this.db.q('INSERT INTO signed_prekeys(device_id,key_id,public_key,signature) VALUES($1,$2,$3,$4)', [a.did, k.keyId, b(k.publicKey), b(k.signature)]);
    await this.db.q('DELETE FROM signed_prekeys WHERE device_id=$1 AND created_at < now() - interval \'30 days\' AND key_id <> $2', [a.did, k.keyId]);
    return { ok: true };
  }

  /** X3DH বান্ডেল: একটি one-time prekey consume হয় (atomic) */
  @Get('keys/bundle/:userId')
  async bundle(@Param('userId', ParseUUIDPipe) userId: string) {
    const d = (await this.db.q('SELECT id,identity_key,registration_id FROM devices WHERE user_id=$1 AND is_active', [userId]))[0];
    if (!d) throw new NotFoundException('no_active_device');
    const spk = (await this.db.q('SELECT key_id,public_key,signature FROM signed_prekeys WHERE device_id=$1 ORDER BY created_at DESC LIMIT 1', [d.id]))[0];
    const otk = (
      await this.db.q(
        `DELETE FROM one_time_prekeys WHERE (device_id,key_id) = (
           SELECT device_id,key_id FROM one_time_prekeys WHERE device_id=$1 ORDER BY key_id LIMIT 1 FOR UPDATE SKIP LOCKED
         ) RETURNING key_id, public_key`, [d.id])
    )[0];
    return {
      userId,
      deviceId: d.id,
      registrationId: d.registration_id,
      identityKey: d.identity_key.toString('base64'),
      signedPrekey: { keyId: spk.key_id, publicKey: spk.public_key.toString('base64'), signature: spk.signature.toString('base64') },
      oneTimePrekey: otk ? { keyId: otk.key_id, publicKey: otk.public_key.toString('base64') } : null,
    };
  }

  /** MVP কন্টাক্ট ডিসকভারি। প্রোডাকশনে প্রাইভেট কন্টাক্ট ডিসকভারি (হ্যাশ/PSI + rate-limit) লাগবে। */
  @Get('users/lookup')
  async lookup(@Query('phone') phone: string) {
    const u = (await this.db.q(`SELECT id FROM users WHERE phone_e164=$1 AND status='active'`, [phone]))[0];
    if (!u) throw new NotFoundException();
    return { userId: u.id };
  }
}
