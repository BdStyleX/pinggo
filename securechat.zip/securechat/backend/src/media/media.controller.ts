import { BadRequestException, Controller, Delete, Get, NotFoundException, Param, ParseUUIDPipe, Put, Req, Res, UseGuards } from '@nestjs/common';
import { promises as fs } from 'fs';
import * as path from 'path';
import { Auth, AuthGuard } from '../common/auth.guard';
import { AccessClaims } from '../common/token.service';
import { Db, cfg } from '../common/infra';

const MAX_BLOB = 100 * 1024 * 1024;

/**
 * এনক্রিপ্টেড মিডিয়া/ভয়েস/ফাইল ব্লব। ক্লায়েন্ট র‍্যান্ডম AES-256 কী দিয়ে এনক্রিপ্ট করে আপলোড করে;
 * কী + blobId থাকে E2EE মেসেজের ভেতরে (এবং ব্যাকআপে), তাই রিস্টোরের সময় ভয়েস মেসেজও ফেরত আসে।
 * MVP: লোকাল ডিস্ক। প্রোডাকশনে এই স্টোরেজটি GCS (signed URL) দিয়ে বদলান।
 * ব্লব মুছে ফেলা হয় শুধু মালিক DELETE করলে: ব্যাকআপ রিস্টোরের জন্য এগুলো ধরে রাখতে হয়।
 */
@Controller('v1/media')
@UseGuards(AuthGuard)
export class MediaController {
  constructor(private db: Db) {}

  private file(id: string) {
    return path.join(cfg.mediaDir(), id.slice(0, 2), id);
  }

  @Put(':id')
  async put(@Auth() a: AccessClaims, @Param('id', ParseUUIDPipe) id: string, @Req() req: any) {
    const body: Buffer = req.body;
    if (!Buffer.isBuffer(body) || body.length < 29 || body.length > MAX_BLOB) throw new BadRequestException('bad_body');
    const exists = (await this.db.q('SELECT owner_id FROM media_blobs WHERE id=$1', [id]))[0];
    if (exists) {
      if (exists.owner_id !== a.sub) throw new BadRequestException('id_taken');
      return { ok: true, duplicate: true };
    }
    const f = this.file(id);
    await fs.mkdir(path.dirname(f), { recursive: true });
    await fs.writeFile(f, body, { flag: 'wx' });
    await this.db.q('INSERT INTO media_blobs(id,owner_id,size_bytes) VALUES($1,$2,$3)', [id, a.sub, body.length]);
    return { ok: true };
  }

  /** blobId ১২৮-বিট র‍্যান্ডম (capability)। কনটেন্ট এনক্রিপ্টেড, তাই কী ছাড়া অর্থহীন। */
  @Get(':id')
  async get(@Param('id', ParseUUIDPipe) id: string, @Res() res: any) {
    const ok = (await this.db.q('SELECT 1 FROM media_blobs WHERE id=$1', [id])).length;
    if (!ok) throw new NotFoundException();
    res.setHeader('Content-Type', 'application/octet-stream');
    res.send(await fs.readFile(this.file(id)));
  }

  @Delete(':id')
  async del(@Auth() a: AccessClaims, @Param('id', ParseUUIDPipe) id: string) {
    const r = await this.db.q('DELETE FROM media_blobs WHERE id=$1 AND owner_id=$2 RETURNING id', [id, a.sub]);
    if (r[0]) await fs.rm(this.file(id), { force: true });
    return { ok: true };
  }
}
