import { OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import { OnGatewayConnection, WebSocketGateway } from '@nestjs/websockets';
import { IncomingMessage } from 'http';
import { randomUUID } from 'crypto';
import { WebSocket } from 'ws';
import { Db, RedisService } from '../common/infra';
import { TokenService } from '../common/token.service';

const MAX_CT_BYTES = 256 * 1024;
const MAILBOX_TTL_DAYS = 30;
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

interface Conn { ws: WebSocket; userId: string; deviceId: string; alive: boolean }

/**
 * Blind relay: শুধু ciphertext রাউট করে। ফ্লো = persist → deliver → ACK-এ মুছে ফেলা।
 * একাধিক পড: userId → podId ম্যাপ Redis-এ, পডে পডে ডেলিভারি Redis Pub/Sub-এ।
 */
@WebSocketGateway({ path: '/v1/ws' })
export class ChatGateway implements OnGatewayConnection, OnModuleInit, OnModuleDestroy {
  private conns = new Map<string, Conn>();
  private readonly podId = randomUUID();
  private sub = this.redis.newConnection();
  private timers: NodeJS.Timeout[] = [];

  constructor(private db: Db, private redis: RedisService, private tokens: TokenService) {}

  async onModuleInit() {
    await this.sub.subscribe(`pod:${this.podId}`, 'kick');
    this.sub.on('message', (channel, msg) => {
      const m = JSON.parse(msg);
      if (channel === 'kick') {
        const c = this.conns.get(m.userId);
        if (c && c.deviceId !== m.deviceId) {
          this.send(c.ws, { t: 'kick', reason: 'SESSION_REPLACED' });
          c.ws.close(4001, 'SESSION_REPLACED');
        }
      } else {
        this.deliverLocal(m.userId, m.frame);
      }
    });
    // heartbeat + presence refresh
    this.timers.push(setInterval(() => {
      for (const c of this.conns.values()) {
        if (!c.alive) { c.ws.terminate(); continue; }
        c.alive = false;
        c.ws.ping();
        this.redis.client.set(`presence:${c.userId}`, this.podId, 'EX', 90).catch(() => {});
      }
    }, 30_000));
    // মেয়াদোত্তীর্ণ অফলাইন মেসেজ মুছে ফেলা
    this.timers.push(setInterval(() => this.db.q('DELETE FROM mailbox WHERE expires_at < now()').catch(() => {}), 3600_000));
  }

  onModuleDestroy() {
    this.timers.forEach(clearInterval);
    this.sub.disconnect();
  }

  async handleConnection(ws: WebSocket, req: IncomingMessage) {
    let claims;
    try {
      const h = req.headers['authorization'] ?? '';
      const token = h.startsWith('Bearer ') ? h.slice(7) : new URL(req.url ?? '', 'http://x').searchParams.get('token') ?? '';
      claims = await this.tokens.verifyAccess(token);
    } catch (e: any) {
      ws.close(e?.message === 'SESSION_REPLACED' ? 4001 : 4401, e?.message ?? 'unauthorized');
      return;
    }
    const prev = this.conns.get(claims.sub);
    if (prev) prev.ws.close(4001, 'SESSION_REPLACED');
    const conn: Conn = { ws, userId: claims.sub, deviceId: claims.did, alive: true };
    this.conns.set(claims.sub, conn);
    await this.redis.client.set(`presence:${claims.sub}`, this.podId, 'EX', 90);

    ws.on('pong', () => (conn.alive = true));
    ws.on('message', (data) => this.onFrame(conn, data.toString()).catch(() => this.send(ws, { t: 'error', code: 'internal' })));
    ws.on('close', async () => {
      if (this.conns.get(conn.userId) === conn) {
        this.conns.delete(conn.userId);
        if ((await this.redis.client.get(`presence:${conn.userId}`)) === this.podId) await this.redis.client.del(`presence:${conn.userId}`);
      }
    });

    await this.replayMailbox(conn);
  }

  private async onFrame(c: Conn, raw: string) {
    if (raw.length > MAX_CT_BYTES * 2) return this.send(c.ws, { t: 'error', code: 'too_large' });
    let f: any;
    try { f = JSON.parse(raw); } catch { return this.send(c.ws, { t: 'error', code: 'bad_json' }); }

    switch (f.t) {
      case 'send': {
        if (!UUID_RE.test(f.id) || !UUID_RE.test(f.to) || typeof f.ct !== 'string') return this.send(c.ws, { t: 'error', code: 'bad_frame', id: f.id });
        const ct = Buffer.from(f.ct, 'base64');
        if (ct.length === 0 || ct.length > MAX_CT_BYTES) return this.send(c.ws, { t: 'error', code: 'bad_size', id: f.id });
        const rec = await this.db.q(`SELECT 1 FROM users WHERE id=$1 AND status='active'`, [f.to]);
        if (!rec.length) return this.send(c.ws, { t: 'error', code: 'no_such_user', id: f.id });
        // ১) আগে persist (ডেলিভারি নিশ্চিত না হওয়া পর্যন্ত হারাবে না), idempotent
        await this.db.q(
          `INSERT INTO mailbox(id,recipient_user_id,sender_user_id,ct,msg_type,expires_at) VALUES($1,$2,$3,$4,$5, now() + ($6 || ' days')::interval) ON CONFLICT (id) DO NOTHING`,
          [f.id, f.to, c.userId, ct, f.type ?? 1, String(MAILBOX_TTL_DAYS)],
        );
        this.send(c.ws, { t: 'sent', id: f.id });
        // ২) অনলাইন থাকলে সাথে সাথে পাঠাও
        await this.route(f.to, { t: 'msg', id: f.id, from: c.userId, ct: f.ct, type: f.type ?? 1, ts: Math.floor(Date.now() / 1000) });
        return;
      }
      case 'ack': {
        if (!UUID_RE.test(f.id)) return;
        const r = await this.db.q('DELETE FROM mailbox WHERE id=$1 AND recipient_user_id=$2 RETURNING sender_user_id', [f.id, c.userId]);
        if (r[0]) await this.route(r[0].sender_user_id, { t: 'delivered', id: f.id });
        return;
      }
      case 'typing': // ephemeral: সংরক্ষণ হয় না
        if (UUID_RE.test(f.to)) await this.route(f.to, { t: 'typing', from: c.userId });
        return;
      default:
        return this.send(c.ws, { t: 'error', code: 'unknown_type' });
    }
  }

  private async replayMailbox(c: Conn) {
    const rows = await this.db.q('SELECT id,sender_user_id,ct,msg_type,created_at FROM mailbox WHERE recipient_user_id=$1 ORDER BY seq LIMIT 500', [c.userId]);
    for (const r of rows) {
      this.send(c.ws, { t: 'msg', id: r.id, from: r.sender_user_id, ct: r.ct.toString('base64'), type: r.msg_type, ts: Math.floor(new Date(r.created_at).getTime() / 1000) });
    }
  }

  private async route(userId: string, frame: object) {
    if (this.deliverLocal(userId, frame)) return;
    const pod = await this.redis.client.get(`presence:${userId}`);
    if (pod && pod !== this.podId) {
      await this.redis.client.publish(`pod:${pod}`, JSON.stringify({ userId, frame }));
    }
    // অফলাইন হলে: মেসেজ মেইলবক্সে আছে; এখানে কনটেন্টবিহীন silent push পাঠানোর হুক (push-service)
  }

  private deliverLocal(userId: string, frame: object): boolean {
    const c = this.conns.get(userId);
    if (!c || c.ws.readyState !== WebSocket.OPEN) return false;
    this.send(c.ws, frame);
    return true;
  }

  private send(ws: WebSocket, frame: object) {
    if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(frame));
  }
}
