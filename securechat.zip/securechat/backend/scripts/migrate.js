const { Client } = require('pg');
const fs = require('fs');
const path = require('path');

(async () => {
  const c = new Client({ connectionString: process.env.DATABASE_URL });
  await c.connect();
  await c.query(fs.readFileSync(path.join(__dirname, '..', 'db', 'schema.sql'), 'utf8'));
  await c.end();
  console.log('schema applied');
})().catch((e) => { console.error(e); process.exit(1); });
